# config.py - database and app settings

DB_CONFIG = {
    'host'    : 'localhost',
    'user'    : 'root',
    'password': 'admin',   # change this to your MySQL password
    'database': 'electricity_billing_db',
    'port'    : 3306
}

APP_TITLE        = "Electricity Billing System"
APP_VERSION      = "1.0.0"
BILL_DUE_DAYS    = 15
COMPANY_NAME     = "City Electricity Distribution Board"
COMPANY_ADDRESS  = "123 Power House Road, New Delhi - 110001"
COMPANY_PHONE    = "+91-11-12345678"
COMPANY_EMAIL    = "billing@cedb.gov.in"


def get_connection():
    import mysql.connector
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        return connection
    except mysql.connector.Error as e:
        print(f"[DB ERROR] Could not connect to database: {e}")
        return None
