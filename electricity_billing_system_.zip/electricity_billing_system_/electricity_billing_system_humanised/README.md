# Electricity Billing System

A desktop-based electricity billing system made using Python, Tkinter and MySQL. Made as a minor project for college submission.

---

## Features

- Login system with Admin and Operator roles
- Add and manage consumer records
- Enter meter readings and calculate bills automatically
- Record payments and track dues
- Generate reports (billing, payment, defaulters, etc.)
- Export bills and receipts as PDF

---

## Tech Stack

- **Language:** Python 3
- **GUI:** Tkinter
- **Database:** MySQL
- **PDF:** ReportLab
- **DB Driver:** mysql-connector-python

---

## Project Structure

```
electricity_billing_system/
├── main.py
├── config.py
├── requirements.txt
├── database/
│   ├── schema.sql
│   └── sample_data.sql
├── modules/
│   ├── auth.py
│   ├── consumer.py
│   ├── billing.py
│   ├── payment.py
│   └── reports.py
├── ui/
│   ├── login_ui.py
│   ├── dashboard_ui.py
│   ├── consumer_ui.py
│   ├── billing_ui.py
│   ├── payment_ui.py
│   └── reports_ui.py
├── utils/
│   ├── validators.py
│   ├── pdf_generator.py
│   └── helpers.py
└── assets/
    └── styles.py
```

---

## How to Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Setup the database
Open MySQL and run:
```sql
source database/schema.sql
source database/sample_data.sql
```

### 3. Update config.py with your MySQL password
```python
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'your_password',
    'database': 'electricity_billing_db',
    'port': 3306
}
```

### 4. Run
```bash
python main.py
```

---

## Login Credentials (Default)

| Role | Username | Password |
|------|----------|----------|
| Admin | admin | Admin@1234 |
| Operator | operator1 | Operator@123 |

> Please change these after first login.

---

## Tariff Rates (can be changed from Admin panel)

**Domestic**
- 0–100 units: ₹3.00/unit
- 101–300 units: ₹5.00/unit
- 301+ units: ₹7.00/unit

**Commercial**
- 0–200 units: ₹6.00/unit
- 201+ units: ₹9.00/unit

**Industrial**
- 0–500 units: ₹8.00/unit
- 501+ units: ₹11.00/unit

---

## Notes

- ReportLab is needed for PDF export. If not installed the PDF button will show a warning.
- The reports section is only visible to Admin users.
- Tested on Python 3.11 and MySQL 8.0.

---

## Author

Minor project submission — BCA/B.Tech (Computer Science)
