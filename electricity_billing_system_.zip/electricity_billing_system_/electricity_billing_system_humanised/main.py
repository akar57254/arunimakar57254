# main.py - run this to start the app

import tkinter as tk
from ui.login_ui     import LoginWindow
from ui.dashboard_ui import DashboardWindow


def start_login():
    root = tk.Tk()
    app  = LoginWindow(root, on_login_success)
    root.mainloop()


def on_login_success(user):
    # close login window and open dashboard
    for widget in tk._default_root.winfo_children():
        widget.destroy()
    tk._default_root.destroy()

    root = tk.Tk()
    DashboardWindow(root, user)
    root.mainloop()


if __name__ == "__main__":
    start_login()
