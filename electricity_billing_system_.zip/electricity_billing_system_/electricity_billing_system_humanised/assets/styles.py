# styles.py - colors, fonts and sizes used across the UI


COLORS = {
    # Backgrounds
    'bg_dark'       : '#1a1a2e',
    'bg_medium'     : '#16213e',
    'bg_light'      : '#0f3460',
    'bg_card'       : '#ffffff',
    'bg_sidebar'    : '#2c3e50',
    'bg_content'    : '#ecf0f1',

    # Accents
    'accent_red'    : '#e74c3c',
    'accent_blue'   : '#3498db',
    'accent_green'  : '#27ae60',
    'accent_orange' : '#f39c12',
    'accent_purple' : '#9b59b6',

    # Text
    'text_white'    : '#ffffff',
    'text_dark'     : '#2c3e50',
    'text_grey'     : '#7f8c8d',
    'text_light'    : '#bdc3c7',

    # Status Colors
    'status_paid'   : '#27ae60',
    'status_unpaid' : '#e74c3c',
    'status_partial': '#f39c12',
    'status_active' : '#27ae60',
    'status_inactive': '#e74c3c',

    # Table
    'table_header'  : '#2c3e50',
    'table_row_odd' : '#ffffff',
    'table_row_even': '#f8f9fa',
    'table_select'  : '#d5e8d4',

    # Buttons
    'btn_primary'   : '#e74c3c',
    'btn_secondary' : '#3498db',
    'btn_success'   : '#27ae60',
    'btn_warning'   : '#f39c12',
    'btn_danger'    : '#c0392b',
    'btn_neutral'   : '#7f8c8d',
}

FONTS = {
    'heading_large' : ('Helvetica', 18, 'bold'),
    'heading_medium': ('Helvetica', 14, 'bold'),
    'heading_small' : ('Helvetica', 12, 'bold'),
    'body'          : ('Helvetica', 10),
    'body_bold'     : ('Helvetica', 10, 'bold'),
    'small'         : ('Helvetica', 9),
    'small_bold'    : ('Helvetica', 9, 'bold'),
    'button'        : ('Helvetica', 10, 'bold'),
    'label'         : ('Helvetica', 10),
    'entry'         : ('Helvetica', 11),
    'mono'          : ('Courier', 10),
}

SIZES = {
    'sidebar_width'  : 220,
    'header_height'  : 60,
    'btn_width'      : 15,
    'btn_height'     : 2,
    'entry_width'    : 30,
    'label_width'    : 18,
    'padding_x'      : 20,
    'padding_y'      : 10,
}

def btn_style(color_key='btn_primary'):
    return {
        'bg'              : COLORS[color_key],
        'fg'              : COLORS['text_white'],
        'font'            : FONTS['button'],
        'relief'          : 'flat',
        'cursor'          : 'hand2',
        'activebackground': COLORS[color_key],
        'activeforeground': COLORS['text_white'],
        'padx'            : 12,
        'pady'            : 6,
    }

def entry_style():
    return {
        'font'            : FONTS['entry'],
        'relief'          : 'solid',
        'bd'              : 1,
        'bg'              : '#ffffff',
        'fg'              : COLORS['text_dark'],
    }

def label_style(bg=None, color='text_dark', bold=False):
    font = FONTS['body_bold'] if bold else FONTS['body']
    return {
        'font': font,
        'bg'  : bg or COLORS['bg_content'],
        'fg'  : COLORS[color],
    }
