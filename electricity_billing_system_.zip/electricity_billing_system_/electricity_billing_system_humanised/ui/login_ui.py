# login_ui.py - login screen


import tkinter as tk
from tkinter import messagebox
from modules.auth import authenticate_user
from assets.styles import COLORS, FONTS


class LoginWindow:
    def __init__(self, root, on_success_callback):
        self.root     = root
        self.callback = on_success_callback

        self.root.title("Electricity Billing System — Login")
        self.root.geometry("480x520")
        self.root.resizable(False, False)
        self.root.configure(bg=COLORS['bg_dark'])
        self._center_window(480, 520)
        self._build_ui()

    def _center_window(self, w, h):
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        x  = (sw - w) // 2
        y  = (sh - h) // 2
        self.root.geometry(f"{w}x{h}+{x}+{y}")

    def _build_ui(self):
        # ── Top decorative bar ──
        tk.Frame(self.root, bg=COLORS['accent_red'], height=5).pack(fill='x')

        # ── Logo / Icon area ──
        icon_frame = tk.Frame(self.root, bg=COLORS['bg_dark'])
        icon_frame.pack(pady=(40, 10))

        tk.Label(icon_frame, text="⚡", font=('Helvetica', 48),
                 bg=COLORS['bg_dark'], fg=COLORS['accent_red']).pack()

        # ── Title ──
        tk.Label(self.root,
                 text="Electricity Billing System",
                 font=FONTS['heading_large'],
                 bg=COLORS['bg_dark'],
                 fg=COLORS['text_white']).pack()

        tk.Label(self.root,
                 text="Please sign in to continue",
                 font=FONTS['small'],
                 bg=COLORS['bg_dark'],
                 fg=COLORS['text_grey']).pack(pady=(4, 30))

        # ── Login Card ──
        card = tk.Frame(self.root, bg=COLORS['bg_medium'],
                        bd=0, relief='flat', padx=40, pady=30)
        card.pack(padx=50, fill='x')

        # Username
        tk.Label(card, text="Username",
                 font=FONTS['body_bold'],
                 bg=COLORS['bg_medium'],
                 fg=COLORS['text_light']).pack(anchor='w')

        self.username_var = tk.StringVar()
        username_entry = tk.Entry(card,
                                  textvariable=self.username_var,
                                  font=FONTS['entry'],
                                  bg='#0f3460', fg='white',
                                  insertbackground='white',
                                  relief='flat', bd=0)
        username_entry.pack(fill='x', pady=(4, 16), ipady=8)
        username_entry.bind('<Return>', lambda e: self.password_entry.focus())

        # Password
        tk.Label(card, text="Password",
                 font=FONTS['body_bold'],
                 bg=COLORS['bg_medium'],
                 fg=COLORS['text_light']).pack(anchor='w')

        self.password_var = tk.StringVar()
        self.password_entry = tk.Entry(card,
                                       textvariable=self.password_var,
                                       font=FONTS['entry'],
                                       bg='#0f3460', fg='white',
                                       insertbackground='white',
                                       show='●', relief='flat', bd=0)
        self.password_entry.pack(fill='x', pady=(4, 24), ipady=8)
        self.password_entry.bind('<Return>', lambda e: self._handle_login())

        # Login Button
        login_btn = tk.Button(card,
                              text="LOGIN  →",
                              font=FONTS['button'],
                              bg=COLORS['accent_red'],
                              fg='white',
                              relief='flat',
                              cursor='hand2',
                              activebackground='#c0392b',
                              activeforeground='white',
                              command=self._handle_login)
        login_btn.pack(fill='x', ipady=10)

        username_entry.focus()

        # ── Footer ──
        tk.Label(self.root,
                 text="© 2026 Electricity Billing System",
                 font=FONTS['small'],
                 bg=COLORS['bg_dark'],
                 fg=COLORS['text_grey']).pack(side='bottom', pady=15)

    def _handle_login(self):
        username = self.username_var.get().strip()
        password = self.password_var.get().strip()

        if not username or not password:
            messagebox.showwarning("Input Required",
                                   "Please enter both username and password.",
                                   parent=self.root)
            return

        result = authenticate_user(username, password)

        if result is None:
            messagebox.showerror("Login Failed",
                                 "Invalid username or password. Please try again.",
                                 parent=self.root)
            self.password_var.set('')
        elif isinstance(result, dict) and 'error' in result:
            messagebox.showerror("Access Denied", result['error'], parent=self.root)
        else:
            self.callback(result)
