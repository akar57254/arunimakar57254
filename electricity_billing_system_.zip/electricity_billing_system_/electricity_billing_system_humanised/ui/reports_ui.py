# reports_ui.py - report generation screens


import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date
from assets.styles import COLORS, FONTS
from modules.reports  import (get_monthly_billing_report,
                               get_payment_collection_report,
                               get_outstanding_dues_report,
                               get_defaulter_list,
                               get_consumer_billing_history,
                               get_consumption_summary)
from utils.helpers import format_currency, format_date


class ReportsFrame(tk.Frame):
    def __init__(self, parent, user):
        super().__init__(parent, bg=COLORS['bg_content'])
        self.user = user
        self._build_ui()

    def _build_ui(self):
        tk.Label(self, text="Reports & Analytics",
                 font=FONTS['heading_medium'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(anchor='w', padx=20, pady=(15, 10))

        nb = ttk.Notebook(self)
        nb.pack(fill='both', expand=True, padx=20, pady=5)

        tabs = [
            ("📅 Monthly Billing",    self._build_monthly_tab),
            ("💰 Payment Collection", self._build_collection_tab),
            ("⚠️ Outstanding Dues",   self._build_dues_tab),
            ("🔴 Defaulters",         self._build_defaulter_tab),
            ("👤 Consumer History",   self._build_history_tab),
            ("📊 Consumption",        self._build_consumption_tab),
        ]
        for title, builder in tabs:
            frame = tk.Frame(nb, bg=COLORS['bg_content'])
            nb.add(frame, text=f"  {title}  ")
            builder(frame)

    def _make_table(self, parent, columns, widths):
        frame = tk.Frame(parent, bg=COLORS['bg_content'])
        frame.pack(fill='both', expand=True, padx=15, pady=5)
        tree = ttk.Treeview(frame, columns=columns,
                             show='headings', selectmode='browse')
        for col, w in zip(columns, widths):
            tree.heading(col, text=col)
            tree.column(col, width=w, anchor='center')
        vsb = ttk.Scrollbar(frame, orient='vertical', command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        tree.pack(side='left', fill='both', expand=True)
        vsb.pack(side='right', fill='y')
        return tree

    def _summary_label(self, parent, text):
        lbl = tk.Label(parent, text=text,
                       font=FONTS['body_bold'],
                       bg=COLORS['bg_content'],
                       fg=COLORS['accent_blue'])
        lbl.pack(anchor='w', padx=15, pady=3)
        return lbl

    def _build_monthly_tab(self, parent):
        ctrl = tk.Frame(parent, bg=COLORS['bg_content'])
        ctrl.pack(fill='x', padx=15, pady=10)

        today = date.today()
        tk.Label(ctrl, text="Year:", font=FONTS['body'],
                 bg=COLORS['bg_content'], fg=COLORS['text_dark']).pack(side='left')
        self.m_year = tk.StringVar(value=str(today.year))
        tk.Entry(ctrl, textvariable=self.m_year, width=6,
                 font=FONTS['entry'], relief='solid', bd=1).pack(side='left', padx=5)

        tk.Label(ctrl, text="Month (1-12):", font=FONTS['body'],
                 bg=COLORS['bg_content'], fg=COLORS['text_dark']).pack(side='left', padx=(10, 0))
        self.m_month = tk.StringVar(value=str(today.month))
        tk.Entry(ctrl, textvariable=self.m_month, width=4,
                 font=FONTS['entry'], relief='solid', bd=1).pack(side='left', padx=5)

        tk.Button(ctrl, text="Generate",
                  font=FONTS['button'],
                  bg=COLORS['accent_red'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._gen_monthly).pack(side='left', padx=10)

        self.m_summary = self._summary_label(parent, "")
        cols    = ('Bill ID', 'Consumer', 'Type', 'Period', 'Units', 'Total (₹)', 'Status')
        widths  = [70, 180, 100, 100, 70, 110, 110]
        self.m_tree = self._make_table(parent, cols, widths)

    def _gen_monthly(self):
        try:
            year  = int(self.m_year.get())
            month = int(self.m_month.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Enter valid year and month.")
            return
        data = get_monthly_billing_report(year, month)
        for row in self.m_tree.get_children():
            self.m_tree.delete(row)
        total = 0
        for b in data:
            self.m_tree.insert('', 'end', values=(
                b['bill_id'], b['full_name'], b['connection_type'],
                b['billing_period'], b['units_consumed'],
                format_currency(b['total_amount']), b['payment_status']
            ))
            total += float(b['total_amount'])
        self.m_summary.config(
            text=f"Total Bills: {len(data)}   |   Total Revenue Billed: {format_currency(total)}"
        )

    def _build_collection_tab(self, parent):
        ctrl = tk.Frame(parent, bg=COLORS['bg_content'])
        ctrl.pack(fill='x', padx=15, pady=10)

        today = date.today()
        for label, attr in [("From (YYYY-MM-DD):", 'c_from'), ("To (YYYY-MM-DD):", 'c_to')]:
            tk.Label(ctrl, text=label, font=FONTS['body'],
                     bg=COLORS['bg_content'], fg=COLORS['text_dark']).pack(side='left')
            var = tk.StringVar(value=str(today))
            setattr(self, attr, var)
            tk.Entry(ctrl, textvariable=var, width=12,
                     font=FONTS['entry'], relief='solid', bd=1).pack(side='left', padx=5)

        tk.Button(ctrl, text="Generate",
                  font=FONTS['button'],
                  bg=COLORS['accent_red'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._gen_collection).pack(side='left', padx=10)

        self.c_summary = self._summary_label(parent, "")
        cols   = ('Receipt No', 'Consumer', 'Period', 'Pay Date', 'Amount (₹)', 'Mode')
        widths = [140, 170, 100, 100, 110, 90]
        self.c_tree = self._make_table(parent, cols, widths)

    def _gen_collection(self):
        data = get_payment_collection_report(self.c_from.get(), self.c_to.get())
        for row in self.c_tree.get_children():
            self.c_tree.delete(row)
        total = 0
        for p in data:
            self.c_tree.insert('', 'end', values=(
                p['receipt_number'], p['full_name'],
                p['billing_period'], format_date(p['payment_date']),
                format_currency(p['amount_paid']), p['payment_mode']
            ))
            total += float(p['amount_paid'])
        self.c_summary.config(
            text=f"Total Transactions: {len(data)}   |   Total Collected: {format_currency(total)}"
        )

    def _build_dues_tab(self, parent):
        ctrl = tk.Frame(parent, bg=COLORS['bg_content'])
        ctrl.pack(fill='x', padx=15, pady=10)
        tk.Button(ctrl, text="Load Outstanding Dues",
                  font=FONTS['button'],
                  bg=COLORS['accent_orange'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._gen_dues).pack(side='left')

        self.d_summary = self._summary_label(parent, "")
        cols   = ('ID', 'Name', 'Type', 'Period', 'Balance (₹)', 'Due Date', 'Days Overdue')
        widths = [55, 170, 100, 100, 110, 95, 100]
        self.d_tree = self._make_table(parent, cols, widths)
        self.d_tree.tag_configure('overdue', background='#fdf2f2')

    def _gen_dues(self):
        data = get_outstanding_dues_report()
        for row in self.d_tree.get_children():
            self.d_tree.delete(row)
        total = 0
        for b in data:
            days = b['days_overdue'] or 0
            tag  = 'overdue' if days > 0 else ''
            self.d_tree.insert('', 'end', values=(
                b['consumer_id'], b['full_name'], b['connection_type'],
                b['billing_period'], format_currency(b['balance_due']),
                format_date(b['due_date']),
                f"{days} days" if days > 0 else "Not due"
            ), tags=(tag,))
            total += float(b['balance_due'])
        self.d_summary.config(
            text=f"Outstanding Accounts: {len(data)}   |   Total Dues: {format_currency(total)}"
        )

    def _build_defaulter_tab(self, parent):
        ctrl = tk.Frame(parent, bg=COLORS['bg_content'])
        ctrl.pack(fill='x', padx=15, pady=10)
        tk.Button(ctrl, text="Load Defaulters",
                  font=FONTS['button'],
                  bg=COLORS['accent_red'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._gen_defaulters).pack(side='left')

        self.def_summary = self._summary_label(parent, "")
        cols   = ('ID', 'Name', 'Contact', 'Type', 'Period', 'Amount (₹)', 'Due Date', 'Days Overdue')
        widths = [55, 150, 100, 100, 100, 110, 95, 100]
        self.def_tree = self._make_table(parent, cols, widths)
        self.def_tree.tag_configure('default', background='#fdf2f2', foreground='#c0392b')

    def _gen_defaulters(self):
        data = get_defaulter_list()
        for row in self.def_tree.get_children():
            self.def_tree.delete(row)
        for d in data:
            self.def_tree.insert('', 'end', values=(
                d['consumer_id'], d['full_name'], d['contact_number'],
                d['connection_type'], d['billing_period'],
                format_currency(d['total_amount']),
                format_date(d['due_date']),
                f"{d['days_overdue']} days"
            ), tags=('default',))
        self.def_summary.config(text=f"Total Defaulters: {len(data)}")

    def _build_history_tab(self, parent):
        ctrl = tk.Frame(parent, bg=COLORS['bg_content'])
        ctrl.pack(fill='x', padx=15, pady=10)
        tk.Label(ctrl, text="Consumer ID:", font=FONTS['body'],
                 bg=COLORS['bg_content'], fg=COLORS['text_dark']).pack(side='left')
        self.h_cid = tk.StringVar()
        tk.Entry(ctrl, textvariable=self.h_cid, width=10,
                 font=FONTS['entry'], relief='solid', bd=1).pack(side='left', padx=5)
        tk.Button(ctrl, text="Load History",
                  font=FONTS['button'],
                  bg=COLORS['accent_blue'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._gen_history).pack(side='left', padx=10)

        self.h_summary = self._summary_label(parent, "")
        cols   = ('Bill ID', 'Period', 'Bill Date', 'Units', 'Total (₹)', 'Paid (₹)', 'Due Date', 'Status')
        widths = [70, 100, 95, 60, 100, 100, 95, 110]
        self.h_tree = self._make_table(parent, cols, widths)
        self.h_tree.tag_configure('Paid',          background='#e8f8f0')
        self.h_tree.tag_configure('Unpaid',        background='#fdf2f2')
        self.h_tree.tag_configure('Partially Paid',background='#fef9e7')

    def _gen_history(self):
        try:
            cid = int(self.h_cid.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Enter a valid Consumer ID.")
            return
        data = get_consumer_billing_history(cid)
        for row in self.h_tree.get_children():
            self.h_tree.delete(row)
        total_billed = total_paid = 0
        for b in data:
            self.h_tree.insert('', 'end', values=(
                b['bill_id'], b['billing_period'], format_date(b['bill_date']),
                b['units_consumed'], format_currency(b['total_amount']),
                format_currency(b['total_paid']),
                format_date(b['due_date']), b['payment_status']
            ), tags=(b['payment_status'],))
            total_billed += float(b['total_amount'])
            total_paid   += float(b['total_paid'])
        self.h_summary.config(
            text=f"Total Billed: {format_currency(total_billed)}   |   Total Paid: {format_currency(total_paid)}   |   Balance: {format_currency(total_billed - total_paid)}"
        )

    def _build_consumption_tab(self, parent):
        ctrl = tk.Frame(parent, bg=COLORS['bg_content'])
        ctrl.pack(fill='x', padx=15, pady=10)
        tk.Label(ctrl, text="Year:", font=FONTS['body'],
                 bg=COLORS['bg_content'], fg=COLORS['text_dark']).pack(side='left')
        self.cons_year = tk.StringVar(value=str(date.today().year))
        tk.Entry(ctrl, textvariable=self.cons_year, width=6,
                 font=FONTS['entry'], relief='solid', bd=1).pack(side='left', padx=5)
        tk.Button(ctrl, text="Generate",
                  font=FONTS['button'],
                  bg=COLORS['accent_purple'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._gen_consumption).pack(side='left', padx=10)

        self.cons_summary = self._summary_label(parent, "")
        cols   = ('Month', 'Type', 'Total Units', 'Total Bills', 'Revenue (₹)')
        widths = [100, 120, 120, 110, 130]
        self.cons_tree = self._make_table(parent, cols, widths)

    def _gen_consumption(self):
        try:
            year = int(self.cons_year.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Enter a valid year.")
            return
        data = get_consumption_summary(year)
        for row in self.cons_tree.get_children():
            self.cons_tree.delete(row)
        MONTHS = ['', 'January', 'February', 'March', 'April', 'May', 'June',
                  'July', 'August', 'September', 'October', 'November', 'December']
        total_units = total_rev = 0
        for r in data:
            self.cons_tree.insert('', 'end', values=(
                MONTHS[int(r['month'])], r['connection_type'],
                f"{r['total_units']:,}", r['total_bills'],
                format_currency(r['total_amount'])
            ))
            total_units += int(r['total_units'])
            total_rev   += float(r['total_amount'])
        self.cons_summary.config(
            text=f"Total Units: {total_units:,}   |   Total Revenue: {format_currency(total_rev)}"
        )
