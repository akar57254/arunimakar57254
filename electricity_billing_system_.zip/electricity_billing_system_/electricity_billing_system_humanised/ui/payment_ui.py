# payment_ui.py - payment recording and overdue account screens


import tkinter as tk
from tkinter import ttk, messagebox
from assets.styles import COLORS, FONTS
from modules.payment  import (get_outstanding_bills, record_payment,
                               get_payment_history, get_all_overdue_accounts,
                               get_payment_by_receipt)
from modules.consumer import get_consumer_by_meter, get_consumer_by_id
from utils.helpers    import format_currency, format_date


class PaymentFrame(tk.Frame):
    def __init__(self, parent, user):
        super().__init__(parent, bg=COLORS['bg_content'])
        self.user = user
        self._build_ui()

    def _build_ui(self):
        tk.Label(self, text="Payment Management",
                 font=FONTS['heading_medium'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(anchor='w', padx=20, pady=(15, 10))

        nb = ttk.Notebook(self)
        nb.pack(fill='both', expand=True, padx=20, pady=5)

        tab1 = tk.Frame(nb, bg=COLORS['bg_content'])
        tab2 = tk.Frame(nb, bg=COLORS['bg_content'])
        tab3 = tk.Frame(nb, bg=COLORS['bg_content'])
        nb.add(tab1, text="  💳  Record Payment  ")
        nb.add(tab2, text="  📋  Payment History  ")
        nb.add(tab3, text="  🔴  Overdue Accounts  ")

        self._build_record_tab(tab1)
        self._build_history_tab(tab2)
        self._build_overdue_tab(tab3)

    def _build_record_tab(self, parent):
        left = tk.Frame(parent, bg=COLORS['bg_content'])
        left.pack(side='left', fill='both', padx=20, pady=20, expand=False)

        # Search
        tk.Label(left, text="Find Consumer",
                 font=FONTS['heading_small'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(anchor='w')

        srow = tk.Frame(left, bg=COLORS['bg_content'])
        srow.pack(fill='x', pady=(5, 15))
        tk.Label(srow, text="Meter / Consumer ID:",
                 font=FONTS['body'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(side='left')
        self.pay_search_var = tk.StringVar()
        tk.Entry(srow, textvariable=self.pay_search_var,
                 font=FONTS['entry'], width=20,
                 relief='solid', bd=1).pack(side='left', padx=8)
        tk.Button(srow, text="Search",
                  font=FONTS['button'],
                  bg=COLORS['accent_blue'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._search_consumer).pack(side='left')

        # Consumer info
        self.pay_info = tk.LabelFrame(left, text=" Consumer ",
                                       font=FONTS['body_bold'],
                                       bg=COLORS['bg_content'],
                                       fg=COLORS['text_grey'])
        self.pay_info.pack(fill='x', pady=5)
        self.pay_name_lbl = tk.Label(self.pay_info, text="—",
                                      font=FONTS['body'],
                                      bg=COLORS['bg_content'],
                                      fg=COLORS['text_dark'])
        self.pay_name_lbl.pack(padx=10, pady=5, anchor='w')

        # Outstanding bills list
        tk.Label(left, text="Outstanding Bills:",
                 font=FONTS['body_bold'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(anchor='w', pady=(10, 3))

        cols = ('Bill ID', 'Period', 'Total (₹)', 'Paid (₹)', 'Balance (₹)', 'Due Date')
        self.bill_tree = ttk.Treeview(left, columns=cols,
                                       show='headings', height=5)
        widths = [65, 100, 95, 95, 95, 95]
        for col, w in zip(cols, widths):
            self.bill_tree.heading(col, text=col)
            self.bill_tree.column(col, width=w, anchor='center')
        self.bill_tree.pack(fill='x')
        self.bill_tree.bind('<<TreeviewSelect>>', self._on_bill_select)

        # Payment entry
        pay_frame = tk.LabelFrame(left, text=" Payment Details ",
                                   font=FONTS['body_bold'],
                                   bg=COLORS['bg_content'],
                                   fg=COLORS['text_grey'])
        pay_frame.pack(fill='x', pady=10)

        for label, attr in [("Amount (₹):", 'pay_amount_var'),]:
            row = tk.Frame(pay_frame, bg=COLORS['bg_content'])
            row.pack(fill='x', padx=10, pady=5)
            tk.Label(row, text=label, font=FONTS['body'],
                     bg=COLORS['bg_content'], fg=COLORS['text_dark'],
                     width=15, anchor='w').pack(side='left')
            var = tk.StringVar()
            setattr(self, attr, var)
            tk.Entry(row, textvariable=var, font=FONTS['entry'],
                     width=15, relief='solid', bd=1).pack(side='left', padx=8)

        mode_row = tk.Frame(pay_frame, bg=COLORS['bg_content'])
        mode_row.pack(fill='x', padx=10, pady=5)
        tk.Label(mode_row, text="Payment Mode:", font=FONTS['body'],
                 bg=COLORS['bg_content'], fg=COLORS['text_dark'],
                 width=15, anchor='w').pack(side='left')
        self.pay_mode_var = tk.StringVar(value='Cash')
        ttk.Combobox(mode_row, textvariable=self.pay_mode_var,
                     values=['Cash', 'Cheque', 'Online', 'UPI'],
                     state='readonly', width=15).pack(side='left', padx=8)

        tk.Button(left, text="✅  Process Payment",
                  font=FONTS['button'],
                  bg=COLORS['accent_green'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._process_payment).pack(pady=10, ipadx=20, ipady=8)

        self.selected_consumer = None
        self.selected_bill_id  = None

    def _search_consumer(self):
        query = self.pay_search_var.get().strip()
        if not query:
            return
        consumer = get_consumer_by_meter(query)
        if not consumer:
            try:
                consumer = get_consumer_by_id(int(query))
            except ValueError:
                pass
        if not consumer:
            messagebox.showerror("Not Found", f"No consumer found: {query}")
            return

        self.selected_consumer = consumer
        self.pay_name_lbl.config(
            text=f"{consumer['full_name']}  |  {consumer['meter_number']}  |  {consumer['connection_type']}"
        )
        self._load_outstanding_bills(consumer['consumer_id'])

    def _load_outstanding_bills(self, consumer_id):
        for row in self.bill_tree.get_children():
            self.bill_tree.delete(row)
        for b in get_outstanding_bills(consumer_id):
            self.bill_tree.insert('', 'end', values=(
                b['bill_id'], b['billing_period'],
                format_currency(b['total_amount']),
                format_currency(b['amount_paid']),
                format_currency(b['balance_due']),
                format_date(b['due_date'])
            ))

    def _on_bill_select(self, _):
        sel = self.bill_tree.selection()
        if sel:
            self.selected_bill_id = self.bill_tree.item(sel[0])['values'][0]
            balance_str = self.bill_tree.item(sel[0])['values'][4]
            # Pre-fill amount
            clean = balance_str.replace('₹', '').replace(',', '').strip()
            self.pay_amount_var.set(clean)

    def _process_payment(self):
        if not self.selected_consumer or not self.selected_bill_id:
            messagebox.showwarning("Selection Required",
                                   "Please search a consumer and select a bill.")
            return
        try:
            amount = float(self.pay_amount_var.get())
        except ValueError:
            messagebox.showerror("Invalid Amount", "Enter a valid payment amount.")
            return

        result = record_payment(
            self.selected_bill_id,
            self.selected_consumer['consumer_id'],
            amount,
            self.pay_mode_var.get(),
            self.user['user_id']
        )
        if isinstance(result, dict) and 'error' in result:
            messagebox.showerror("Payment Error", result['error'])
            return

        receipt_no = result
        messagebox.showinfo("Payment Successful",
                            f"Payment recorded!\nReceipt: {receipt_no}")
        self._load_outstanding_bills(self.selected_consumer['consumer_id'])
        self.pay_amount_var.set('')

        # Offer PDF receipt
        data = get_payment_by_receipt(receipt_no)
        if data and messagebox.askyesno("Print Receipt",
                                         "Would you like to save a PDF receipt?"):
            try:
                from utils.pdf_generator import generate_receipt_pdf
                path = generate_receipt_pdf(data)
                if path:
                    messagebox.showinfo("Receipt Saved", f"Receipt saved to:\n{path}")
            except Exception as e:
                messagebox.showerror("PDF Error", str(e))

    def _build_history_tab(self, parent):
        top = tk.Frame(parent, bg=COLORS['bg_content'])
        top.pack(fill='x', padx=20, pady=15)
        tk.Label(top, text="Consumer ID/Meter:",
                 font=FONTS['body'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(side='left')
        self.hist_search_var = tk.StringVar()
        tk.Entry(top, textvariable=self.hist_search_var,
                 font=FONTS['entry'], width=20,
                 relief='solid', bd=1).pack(side='left', padx=8)
        tk.Button(top, text="Load History",
                  font=FONTS['button'],
                  bg=COLORS['accent_blue'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._load_history).pack(side='left')

        cols = ('Receipt No', 'Period', 'Pay Date', 'Amount (₹)', 'Mode', 'Bill Total (₹)')
        self.hist_tree = ttk.Treeview(parent, columns=cols,
                                       show='headings', selectmode='browse')
        widths = [150, 110, 100, 110, 80, 110]
        for col, w in zip(cols, widths):
            self.hist_tree.heading(col, text=col)
            self.hist_tree.column(col, width=w, anchor='center')

        vsb = ttk.Scrollbar(parent, orient='vertical', command=self.hist_tree.yview)
        self.hist_tree.configure(yscrollcommand=vsb.set)
        self.hist_tree.pack(side='left', fill='both', expand=True, padx=(20, 0), pady=5)
        vsb.pack(side='left', fill='y', pady=5)

    def _load_history(self):
        for row in self.hist_tree.get_children():
            self.hist_tree.delete(row)
        query = self.hist_search_var.get().strip()
        if not query:
            return
        consumer = get_consumer_by_meter(query)
        if not consumer:
            try:
                consumer = get_consumer_by_id(int(query))
            except ValueError:
                pass
        if not consumer:
            messagebox.showerror("Not Found", f"No consumer found: {query}")
            return
        for p in get_payment_history(consumer['consumer_id']):
            self.hist_tree.insert('', 'end', values=(
                p['receipt_number'], p['billing_period'],
                format_date(p['payment_date']),
                format_currency(p['amount_paid']),
                p['payment_mode'],
                format_currency(p['total_amount'])
            ))

    def _build_overdue_tab(self, parent):
        top = tk.Frame(parent, bg=COLORS['bg_content'])
        top.pack(fill='x', padx=20, pady=15)
        tk.Label(top, text="Overdue Accounts",
                 font=FONTS['heading_small'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['accent_red']).pack(side='left')
        tk.Button(top, text="🔄 Refresh",
                  font=FONTS['small'],
                  bg=COLORS['accent_blue'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._load_overdue).pack(side='right')

        cols = ('ID', 'Name', 'Meter', 'Type', 'Period', 'Amount (₹)', 'Due Date', 'Days Overdue')
        self.over_tree = ttk.Treeview(parent, columns=cols,
                                       show='headings', selectmode='browse')
        widths = [55, 160, 90, 100, 90, 100, 95, 100]
        for col, w in zip(cols, widths):
            self.over_tree.heading(col, text=col)
            self.over_tree.column(col, width=w, anchor='center')

        self.over_tree.tag_configure('overdue', background='#fdf2f2', foreground='#c0392b')

        vsb = ttk.Scrollbar(parent, orient='vertical', command=self.over_tree.yview)
        self.over_tree.configure(yscrollcommand=vsb.set)
        self.over_tree.pack(side='left', fill='both', expand=True, padx=(20, 0), pady=5)
        vsb.pack(side='left', fill='y', pady=5)

        self._load_overdue()

    def _load_overdue(self):
        for row in self.over_tree.get_children():
            self.over_tree.delete(row)
        for a in get_all_overdue_accounts():
            self.over_tree.insert('', 'end', values=(
                a['consumer_id'], a['full_name'], a['meter_number'],
                a['connection_type'], a['billing_period'],
                format_currency(a['total_amount']),
                format_date(a['due_date']),
                f"{a['days_overdue']} days"
            ), tags=('overdue',))
