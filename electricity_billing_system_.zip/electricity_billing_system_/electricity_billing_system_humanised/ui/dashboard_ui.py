# dashboard_ui.py - main window with sidebar and dashboard stats


import tkinter as tk
from tkinter import messagebox
from assets.styles import COLORS, FONTS, SIZES
from modules.consumer import get_consumer_count
from modules.billing  import get_monthly_bill_count, get_monthly_revenue
from modules.payment  import get_total_outstanding, get_overdue_count
from modules.auth     import get_all_users


class DashboardWindow:
    def __init__(self, root, user):
        self.root    = root
        self.user    = user
        self.is_admin = (user['role'] == 'Administrator')

        self.root.title(f"Electricity Billing System — {user['role']}")
        self.root.geometry("1100x680")
        self.root.configure(bg=COLORS['bg_content'])
        self._center_window(1100, 680)
        self.root.resizable(True, True)

        self.current_frame = None
        self._build_layout()
        self._show_home()

    def _center_window(self, w, h):
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        x  = (sw - w) // 2
        y  = (sh - h) // 2
        self.root.geometry(f"{w}x{h}+{x}+{y}")

    def _build_layout(self):
        # Top header bar
        self.header = tk.Frame(self.root, bg=COLORS['bg_sidebar'],
                               height=SIZES['header_height'])
        self.header.pack(fill='x', side='top')
        self.header.pack_propagate(False)
        self._build_header()

        # Body: sidebar + content
        body = tk.Frame(self.root, bg=COLORS['bg_content'])
        body.pack(fill='both', expand=True)

        # Sidebar
        self.sidebar = tk.Frame(body, bg=COLORS['bg_sidebar'],
                                width=SIZES['sidebar_width'])
        self.sidebar.pack(fill='y', side='left')
        self.sidebar.pack_propagate(False)
        self._build_sidebar()

        # Content area
        self.content = tk.Frame(body, bg=COLORS['bg_content'])
        self.content.pack(fill='both', expand=True, side='left')

    def _build_header(self):
        tk.Label(self.header, text="⚡ Electricity Billing System",
                 font=FONTS['heading_medium'],
                 bg=COLORS['bg_sidebar'], fg=COLORS['text_white']).pack(side='left', padx=20)

        tk.Label(self.header,
                 text=f"👤  {self.user['full_name']}  |  {self.user['role']}",
                 font=FONTS['body'],
                 bg=COLORS['bg_sidebar'], fg=COLORS['text_light']).pack(side='right', padx=20)

    def _build_sidebar(self):
        tk.Label(self.sidebar, text="NAVIGATION",
                 font=FONTS['small_bold'],
                 bg=COLORS['bg_sidebar'],
                 fg=COLORS['text_grey']).pack(pady=(20, 5), padx=15, anchor='w')

        # Nav items: (label, icon, command, admin_only)
        nav_items = [
            ("Home",             "🏠", self._show_home,        False),
            ("Consumers",        "👥", self._show_consumers,   False),
            ("Meter & Billing",  "📊", self._show_billing,     False),
            ("Payments",         "💳", self._show_payments,    False),
            ("Reports",          "📈", self._show_reports,     True),
            ("Admin Panel",      "⚙️", self._show_admin,       True),
        ]

        self.nav_buttons = {}
        for label, icon, cmd, admin_only in nav_items:
            if admin_only and not self.is_admin:
                continue
            btn = tk.Button(self.sidebar,
                            text=f"  {icon}  {label}",
                            font=FONTS['body'],
                            bg=COLORS['bg_sidebar'],
                            fg=COLORS['text_white'],
                            relief='flat', anchor='w',
                            cursor='hand2',
                            activebackground=COLORS['accent_red'],
                            activeforeground='white',
                            command=cmd)
            btn.pack(fill='x', padx=10, pady=2, ipady=8)
            self.nav_buttons[label] = btn

        # Logout at bottom
        tk.Frame(self.sidebar, bg=COLORS['bg_sidebar']).pack(fill='y', expand=True)
        tk.Button(self.sidebar,
                  text="  🚪  Logout",
                  font=FONTS['body'],
                  bg=COLORS['bg_sidebar'],
                  fg=COLORS['accent_red'],
                  relief='flat', anchor='w',
                  cursor='hand2',
                  command=self._logout).pack(fill='x', padx=10, pady=10, ipady=8)

    def _clear_content(self):
        for widget in self.content.winfo_children():
            widget.destroy()

    def _set_active_nav(self, label):
        for lbl, btn in self.nav_buttons.items():
            if lbl == label:
                btn.config(bg=COLORS['accent_red'])
            else:
                btn.config(bg=COLORS['bg_sidebar'])

    def _show_home(self):
        self._clear_content()
        self._set_active_nav("Home")

        frame = tk.Frame(self.content, bg=COLORS['bg_content'])
        frame.pack(fill='both', expand=True, padx=25, pady=20)

        tk.Label(frame, text="Dashboard Overview",
                 font=FONTS['heading_medium'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(anchor='w', pady=(0, 20))

        # Stats cards
        stats_frame = tk.Frame(frame, bg=COLORS['bg_content'])
        stats_frame.pack(fill='x')

        try:
            stats = [
                ("Total Consumers",    get_consumer_count(),               "👥", COLORS['accent_blue']),
                ("Bills This Month",   get_monthly_bill_count(),            "🧾", COLORS['accent_purple']),
                ("Revenue Billed",     f"₹{get_monthly_revenue():,.2f}",    "💰", COLORS['accent_green']),
                ("Outstanding Dues",   f"₹{get_total_outstanding():,.2f}",  "⚠️", COLORS['accent_orange']),
                ("Overdue Accounts",   get_overdue_count(),                 "🔴", COLORS['accent_red']),
                ("System Users",       len(get_all_users()),                "👤", COLORS['text_grey']),
            ]
        except Exception:
            stats = [("Dashboard", "Connect DB", "⚡", COLORS['accent_red'])]

        for i, (title, value, icon, color) in enumerate(stats):
            card = tk.Frame(stats_frame, bg='white', relief='flat', bd=1)
            card.grid(row=i // 3, column=i % 3, padx=10, pady=10, sticky='nsew')
            stats_frame.columnconfigure(i % 3, weight=1)

            tk.Label(card, text=icon, font=('Helvetica', 24),
                     bg='white').pack(pady=(15, 5))
            tk.Label(card, text=str(value),
                     font=FONTS['heading_medium'],
                     bg='white', fg=color).pack()
            tk.Label(card, text=title,
                     font=FONTS['small'],
                     bg='white', fg=COLORS['text_grey']).pack(pady=(2, 15))

        # Welcome message
        tk.Label(frame,
                 text=f"\nWelcome, {self.user['full_name']}! You are logged in as {self.user['role']}.",
                 font=FONTS['body'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_grey']).pack(anchor='w', pady=20)

    def _show_consumers(self):
        self._clear_content()
        self._set_active_nav("Consumers")
        from ui.consumer_ui import ConsumerFrame
        ConsumerFrame(self.content, self.user).pack(fill='both', expand=True)

    def _show_billing(self):
        self._clear_content()
        self._set_active_nav("Meter & Billing")
        from ui.billing_ui import BillingFrame
        BillingFrame(self.content, self.user).pack(fill='both', expand=True)

    def _show_payments(self):
        self._clear_content()
        self._set_active_nav("Payments")
        from ui.payment_ui import PaymentFrame
        PaymentFrame(self.content, self.user).pack(fill='both', expand=True)

    def _show_reports(self):
        self._clear_content()
        self._set_active_nav("Reports")
        from ui.reports_ui import ReportsFrame
        ReportsFrame(self.content, self.user).pack(fill='both', expand=True)

    def _show_admin(self):
        self._clear_content()
        self._set_active_nav("Admin Panel")
        from ui.admin_ui import AdminFrame
        AdminFrame(self.content, self.user).pack(fill='both', expand=True)

    def _logout(self):
        if messagebox.askyesno("Logout", "Are you sure you want to logout?",
                               parent=self.root):
            self.root.destroy()
            import main
            main.start_login()
