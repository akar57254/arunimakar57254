# consumer_ui.py - consumer management screen


import tkinter as tk
from tkinter import ttk, messagebox
from assets.styles import COLORS, FONTS
from modules.consumer import (register_consumer, get_all_consumers,
                               search_consumers, update_consumer,
                               set_consumer_status, get_consumer_by_id)
from utils.validators import validate_consumer_form
from utils.helpers import format_date


class ConsumerFrame(tk.Frame):
    def __init__(self, parent, user):
        super().__init__(parent, bg=COLORS['bg_content'])
        self.user = user
        self._build_ui()
        self._load_consumers()

    def _build_ui(self):
        # ── Header ──
        hdr = tk.Frame(self, bg=COLORS['bg_content'])
        hdr.pack(fill='x', padx=20, pady=(15, 5))
        tk.Label(hdr, text="Consumer Management",
                 font=FONTS['heading_medium'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(side='left')
        tk.Button(hdr, text="＋  Add New Consumer",
                  font=FONTS['button'],
                  bg=COLORS['accent_green'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._open_add_form).pack(side='right')

        # ── Search bar ──
        search_frame = tk.Frame(self, bg=COLORS['bg_content'])
        search_frame.pack(fill='x', padx=20, pady=5)
        tk.Label(search_frame, text="Search:",
                 font=FONTS['body'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(side='left')
        self.search_var = tk.StringVar()
        self.search_var.trace('w', lambda *a: self._do_search())
        tk.Entry(search_frame, textvariable=self.search_var,
                 font=FONTS['entry'], width=35,
                 relief='solid', bd=1).pack(side='left', padx=8)
        tk.Button(search_frame, text="🔄 Refresh",
                  font=FONTS['small'],
                  bg=COLORS['accent_blue'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._load_consumers).pack(side='left', padx=5)

        # ── Table ──
        table_frame = tk.Frame(self, bg=COLORS['bg_content'])
        table_frame.pack(fill='both', expand=True, padx=20, pady=10)

        cols = ('ID', 'Name', 'Meter No', 'Type', 'Contact', 'Load(kW)', 'Status')
        self.tree = ttk.Treeview(table_frame, columns=cols,
                                  show='headings', selectmode='browse')

        widths = [60, 200, 100, 100, 110, 80, 80]
        for col, w in zip(cols, widths):
            self.tree.heading(col, text=col)
            self.tree.column(col, width=w, anchor='center')

        style = ttk.Style()
        style.configure('Treeview.Heading',
                        font=FONTS['body_bold'],
                        background=COLORS['table_header'],
                        foreground='white')
        style.configure('Treeview', rowheight=28, font=FONTS['body'])

        vsb = ttk.Scrollbar(table_frame, orient='vertical',
                             command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side='left', fill='both', expand=True)
        vsb.pack(side='right', fill='y')

        self.tree.tag_configure('active',   background='#e8f8f0')
        self.tree.tag_configure('inactive', background='#fdf2f2')

        # ── Action buttons ──
        btn_frame = tk.Frame(self, bg=COLORS['bg_content'])
        btn_frame.pack(fill='x', padx=20, pady=(0, 15))
        for text, color, cmd in [
            ("✏️  Edit",        COLORS['accent_blue'],   self._edit_consumer),
            ("✅  Activate",    COLORS['accent_green'],  lambda: self._toggle_status('Active')),
            ("🚫  Deactivate",  COLORS['accent_orange'], lambda: self._toggle_status('Inactive')),
            ("👁  View Profile", COLORS['bg_sidebar'],   self._view_profile),
        ]:
            tk.Button(btn_frame, text=text, font=FONTS['small'],
                      bg=color, fg='white', relief='flat',
                      cursor='hand2', command=cmd).pack(side='left', padx=5, ipady=4)

    def _load_consumers(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for c in get_all_consumers():
            tag = 'active' if c['status'] == 'Active' else 'inactive'
            self.tree.insert('', 'end', values=(
                c['consumer_id'], c['full_name'], c['meter_number'],
                c['connection_type'], c['contact_number'],
                c['sanctioned_load'], c['status']
            ), tags=(tag,))

    def _do_search(self):
        kw = self.search_var.get().strip()
        for row in self.tree.get_children():
            self.tree.delete(row)
        results = search_consumers(kw) if kw else get_all_consumers()
        for c in results:
            tag = 'active' if c.get('status') == 'Active' else 'inactive'
            self.tree.insert('', 'end', values=(
                c['consumer_id'], c['full_name'], c['meter_number'],
                c.get('connection_type', ''), c.get('contact_number', ''),
                c.get('sanctioned_load', ''), c.get('status', '')
            ), tags=(tag,))

    def _get_selected_id(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("No Selection", "Please select a consumer first.")
            return None
        return self.tree.item(sel[0])['values'][0]

    def _toggle_status(self, status):
        cid = self._get_selected_id()
        if cid:
            if set_consumer_status(cid, status):
                self._load_consumers()
                messagebox.showinfo("Success", f"Consumer status set to {status}.")
            else:
                messagebox.showerror("Error", "Could not update status.")

    def _view_profile(self):
        cid = self._get_selected_id()
        if cid:
            consumer = get_consumer_by_id(cid)
            if consumer:
                _ProfileWindow(self, consumer)

    def _open_add_form(self):
        _ConsumerFormWindow(self, None, self._load_consumers)

    def _edit_consumer(self):
        cid = self._get_selected_id()
        if cid:
            consumer = get_consumer_by_id(cid)
            if consumer:
                _ConsumerFormWindow(self, consumer, self._load_consumers)


class _ConsumerFormWindow(tk.Toplevel):
    def __init__(self, parent, consumer, on_save):
        super().__init__(parent)
        self.consumer = consumer
        self.on_save  = on_save
        self.is_edit  = consumer is not None

        self.title("Edit Consumer" if self.is_edit else "Add New Consumer")
        self.geometry("520x600")
        self.resizable(False, False)
        self.configure(bg=COLORS['bg_content'])
        self.grab_set()
        self._build()

    def _build(self):
        tk.Label(self, text="Edit Consumer" if self.is_edit else "Register New Consumer",
                 font=FONTS['heading_medium'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(pady=(20, 15))

        form = tk.Frame(self, bg=COLORS['bg_content'])
        form.pack(padx=30, fill='x')

        self.vars = {}
        fields = [
            ('full_name',       'Full Name *',        not self.is_edit),
            ('address',         'Address *',          True),
            ('contact_number',  'Contact Number *',   True),
            ('email',           'Email',              True),
            ('meter_number',    'Meter Number *',     not self.is_edit),
            ('sanctioned_load', 'Sanctioned Load (kW) *', True),
            ('connection_date', 'Connection Date (YYYY-MM-DD)', not self.is_edit),
        ]

        for key, label, editable in fields:
            tk.Label(form, text=label, font=FONTS['small_bold'],
                     bg=COLORS['bg_content'],
                     fg=COLORS['text_dark']).pack(anchor='w', pady=(8, 0))
            var = tk.StringVar()
            if self.consumer:
                var.set(str(self.consumer.get(key, '') or ''))
            self.vars[key] = var
            state = 'normal' if editable else 'disabled'
            tk.Entry(form, textvariable=var, font=FONTS['entry'],
                     relief='solid', bd=1, state=state).pack(fill='x', ipady=4)

        # Connection type dropdown
        tk.Label(form, text="Connection Type *", font=FONTS['small_bold'],
                 bg=COLORS['bg_content'], fg=COLORS['text_dark']).pack(anchor='w', pady=(8, 0))
        self.conn_var = tk.StringVar(value=self.consumer['connection_type'] if self.consumer else 'Domestic')
        state = 'disabled' if self.is_edit else 'readonly'
        ttk.Combobox(form, textvariable=self.conn_var,
                     values=['Domestic', 'Commercial', 'Industrial'],
                     state=state, font=FONTS['entry']).pack(fill='x', ipady=4)

        # Buttons
        btn_frame = tk.Frame(self, bg=COLORS['bg_content'])
        btn_frame.pack(pady=20)
        tk.Button(btn_frame, text="💾  Save",
                  font=FONTS['button'],
                  bg=COLORS['accent_green'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._save).pack(side='left', padx=10, ipadx=20, ipady=6)
        tk.Button(btn_frame, text="✖  Cancel",
                  font=FONTS['button'],
                  bg=COLORS['text_grey'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self.destroy).pack(side='left', padx=10, ipadx=20, ipady=6)

    def _save(self):
        data = {k: v.get().strip() for k, v in self.vars.items()}
        data['connection_type'] = self.conn_var.get()

        errors = validate_consumer_form(data)
        if errors:
            messagebox.showerror("Validation Error", "\n".join(errors), parent=self)
            return

        if self.is_edit:
            ok = update_consumer(self.consumer['consumer_id'], data)
            msg = "Consumer updated successfully."
        else:
            result = register_consumer(data)
            if isinstance(result, dict) and 'error' in result:
                messagebox.showerror("Error", result['error'], parent=self)
                return
            ok = result is not None
            msg = f"Consumer registered! ID: {result}"

        if ok:
            messagebox.showinfo("Success", msg, parent=self)
            self.on_save()
            self.destroy()
        else:
            messagebox.showerror("Error", "Operation failed. Check input.", parent=self)


class _ProfileWindow(tk.Toplevel):
    def __init__(self, parent, consumer):
        super().__init__(parent)
        self.title(f"Profile — {consumer['full_name']}")
        self.geometry("420x480")
        self.resizable(False, False)
        self.configure(bg=COLORS['bg_content'])
        self.grab_set()

        tk.Label(self, text="👤  Consumer Profile",
                 font=FONTS['heading_medium'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(pady=(20, 10))

        frame = tk.Frame(self, bg=COLORS['bg_content'])
        frame.pack(padx=30, fill='x')

        fields = [
            ('Consumer ID',     consumer['consumer_id']),
            ('Full Name',       consumer['full_name']),
            ('Address',         consumer['address']),
            ('Contact',         consumer['contact_number']),
            ('Email',           consumer['email'] or '—'),
            ('Meter Number',    consumer['meter_number']),
            ('Connection Type', consumer['connection_type']),
            ('Sanctioned Load', f"{consumer['sanctioned_load']} kW"),
            ('Connected On',    format_date(consumer['connection_date'])),
            ('Status',          consumer['status']),
        ]
        for label, value in fields:
            row = tk.Frame(frame, bg=COLORS['bg_content'])
            row.pack(fill='x', pady=3)
            tk.Label(row, text=f"{label}:", font=FONTS['body_bold'],
                     bg=COLORS['bg_content'], fg=COLORS['text_dark'],
                     width=18, anchor='w').pack(side='left')
            color = COLORS['status_active'] if value == 'Active' else \
                    COLORS['status_inactive'] if value == 'Inactive' else \
                    COLORS['text_dark']
            tk.Label(row, text=str(value), font=FONTS['body'],
                     bg=COLORS['bg_content'], fg=color).pack(side='left')

        tk.Button(self, text="Close", font=FONTS['button'],
                  bg=COLORS['accent_red'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self.destroy).pack(pady=20, ipadx=30, ipady=6)
