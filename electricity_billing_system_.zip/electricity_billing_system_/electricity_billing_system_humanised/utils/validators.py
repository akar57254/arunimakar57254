# validators.py - form validation functions


import re


def is_valid_name(name):
    """Name must contain only letters, spaces, and dots."""
    return bool(re.match(r'^[A-Za-z\s.]+$', name.strip())) if name.strip() else False


def is_valid_phone(phone):
    """Phone must be exactly 10 digits."""
    return bool(re.match(r'^\d{10}$', phone.strip()))


def is_valid_email(email):
    """Validate email format. Empty is acceptable (optional field)."""
    if not email or not email.strip():
        return True
    return bool(re.match(
        r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$',
        email.strip()
    ))


def is_positive_number(value):
    """Value must be a positive float or int."""
    try:
        return float(str(value).strip()) > 0
    except (ValueError, TypeError):
        return False


def is_non_negative_int(value):
    """Value must be a non-negative integer (meter reading)."""
    try:
        return int(str(value).strip()) >= 0
    except (ValueError, TypeError):
        return False


def is_valid_billing_month(month_str):
    """Billing month must be in YYYY-MM format, e.g. 2026-05."""
    return bool(re.match(r'^\d{4}-(0[1-9]|1[0-2])$', str(month_str).strip()))


def is_valid_meter_number(meter):
    """Meter number must be 3–20 alphanumeric characters."""
    return bool(re.match(r'^[A-Za-z0-9\-]{3,20}$', str(meter).strip()))


def validate_consumer_form(data):
    """
    Validate all fields of the consumer registration form.
    Returns list of error messages (empty list = valid).
    """
    errors = []

    if not data.get('full_name', '').strip():
        errors.append("Full name is required.")
    elif not is_valid_name(data['full_name']):
        errors.append("Full name must contain only letters and spaces.")

    if not data.get('address', '').strip():
        errors.append("Address is required.")

    if not data.get('contact_number', '').strip():
        errors.append("Contact number is required.")
    elif not is_valid_phone(data['contact_number']):
        errors.append("Contact number must be exactly 10 digits.")

    if data.get('email') and not is_valid_email(data['email']):
        errors.append("Invalid email address format.")

    if not data.get('meter_number', '').strip():
        errors.append("Meter number is required.")
    elif not is_valid_meter_number(data['meter_number']):
        errors.append("Meter number must be 3–20 alphanumeric characters.")

    if not data.get('connection_type'):
        errors.append("Connection type is required.")

    if not data.get('sanctioned_load'):
        errors.append("Sanctioned load is required.")
    elif not is_positive_number(data['sanctioned_load']):
        errors.append("Sanctioned load must be a positive number.")

    if not data.get('connection_date'):
        errors.append("Connection date is required.")

    return errors
