# pdf_generator.py - generate bill and receipt PDFs using ReportLab


import os
from datetime import date

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.units import cm
    from reportlab.platypus import (SimpleDocTemplate, Table, TableStyle,
                                    Paragraph, Spacer, HRFlowable)
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False

from config import COMPANY_NAME, COMPANY_ADDRESS, COMPANY_PHONE, COMPANY_EMAIL
from utils.helpers import format_currency, format_date, generate_bill_number


def generate_bill_pdf(bill_data, output_path=None):
    """
    Generate a PDF electricity bill.
    bill_data: dict from billing.get_bill_by_id()
    Returns file path of generated PDF.
    """
    if not REPORTLAB_AVAILABLE:
        print("[PDF] ReportLab not installed. Run: pip install reportlab")
        return None

    if output_path is None:
        os.makedirs("reports", exist_ok=True)
        output_path = f"reports/bill_{bill_data['bill_id']}_{date.today()}.pdf"

    doc    = SimpleDocTemplate(output_path, pagesize=A4,
                                topMargin=1*cm, bottomMargin=1*cm,
                                leftMargin=2*cm, rightMargin=2*cm)
    styles = getSampleStyleSheet()
    story  = []

    # --- Header ---
    title_style = ParagraphStyle('title', parent=styles['Title'],
                                  fontSize=16, textColor=colors.HexColor('#2c3e50'),
                                  spaceAfter=4)
    sub_style   = ParagraphStyle('sub', parent=styles['Normal'],
                                  fontSize=9, textColor=colors.grey,
                                  alignment=TA_CENTER)

    story.append(Paragraph(COMPANY_NAME, title_style))
    story.append(Paragraph(COMPANY_ADDRESS, sub_style))
    story.append(Paragraph(f"Phone: {COMPANY_PHONE} | Email: {COMPANY_EMAIL}", sub_style))
    story.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor('#e74c3c')))
    story.append(Spacer(1, 0.3*cm))

    bill_title = ParagraphStyle('btitle', parent=styles['Heading2'],
                                 fontSize=13, textColor=colors.HexColor('#e74c3c'),
                                 alignment=TA_CENTER)
    story.append(Paragraph("ELECTRICITY BILL", bill_title))
    story.append(Spacer(1, 0.3*cm))

    # --- Consumer & Bill Info ---
    info_data = [
        ["Bill Number",    generate_bill_number(bill_data['bill_id']),
         "Bill Date",      format_date(bill_data['bill_date'])],
        ["Consumer ID",    str(bill_data['consumer_id']),
         "Due Date",       format_date(bill_data['due_date'])],
        ["Name",           bill_data['full_name'],
         "Meter Number",   bill_data['meter_number']],
        ["Address",        bill_data['address'],
         "Connection",     bill_data['connection_type']],
        ["Billing Period", str(bill_data['billing_period']),
         "Contact",        str(bill_data.get('contact_number', '—'))],
    ]
    info_table = Table(info_data, colWidths=[3.5*cm, 7*cm, 3.5*cm, 4*cm])
    info_table.setStyle(TableStyle([
        ('FONTSIZE',    (0, 0), (-1, -1), 8),
        ('FONTNAME',    (0, 0), (0, -1),  'Helvetica-Bold'),
        ('FONTNAME',    (2, 0), (2, -1),  'Helvetica-Bold'),
        ('TEXTCOLOR',   (0, 0), (0, -1),  colors.HexColor('#2c3e50')),
        ('TEXTCOLOR',   (2, 0), (2, -1),  colors.HexColor('#2c3e50')),
        ('BACKGROUND',  (0, 0), (-1, -1), colors.HexColor('#f8f9fa')),
        ('GRID',        (0, 0), (-1, -1), 0.5, colors.lightgrey),
        ('ROWBACKGROUNDS', (0, 0), (-1, -1), [colors.white, colors.HexColor('#f8f9fa')]),
        ('VALIGN',      (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING',  (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(info_table)
    story.append(Spacer(1, 0.4*cm))

    # --- Meter Reading Section ---
    story.append(Paragraph("Meter Reading Details", styles['Heading3']))
    reading_data = [
        ["Previous Reading", "Current Reading", "Units Consumed"],
        [str(bill_data.get('previous_reading', 0)),
         str(bill_data.get('current_reading', 0)),
         str(bill_data['units_consumed'])]
    ]
    reading_table = Table(reading_data, colWidths=[6*cm, 6*cm, 6*cm])
    reading_table.setStyle(TableStyle([
        ('BACKGROUND',    (0, 0), (-1, 0),  colors.HexColor('#2c3e50')),
        ('TEXTCOLOR',     (0, 0), (-1, 0),  colors.white),
        ('FONTNAME',      (0, 0), (-1, 0),  'Helvetica-Bold'),
        ('FONTSIZE',      (0, 0), (-1, -1), 9),
        ('ALIGN',         (0, 0), (-1, -1), 'CENTER'),
        ('GRID',          (0, 0), (-1, -1), 0.5, colors.grey),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white]),
        ('TOPPADDING',    (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(reading_table)
    story.append(Spacer(1, 0.4*cm))

    # --- Charge Breakdown ---
    story.append(Paragraph("Bill Breakdown", styles['Heading3']))
    charge_data = [
        ["Description", "Amount"],
        ["Unit Charges",      format_currency(bill_data['unit_charge'])],
        ["Fixed Charge",      format_currency(bill_data['fixed_charge'])],
        ["Fuel Surcharge",    format_currency(bill_data['surcharge'])],
        ["Tax",               format_currency(bill_data['tax_amount'])],
    ]
    charge_table = Table(charge_data, colWidths=[12*cm, 6*cm])
    charge_table.setStyle(TableStyle([
        ('BACKGROUND',    (0, 0), (-1, 0),  colors.HexColor('#2c3e50')),
        ('TEXTCOLOR',     (0, 0), (-1, 0),  colors.white),
        ('FONTNAME',      (0, 0), (-1, 0),  'Helvetica-Bold'),
        ('FONTSIZE',      (0, 0), (-1, -1), 9),
        ('ALIGN',         (1, 0), (1, -1),  'RIGHT'),
        ('GRID',          (0, 0), (-1, -1), 0.5, colors.grey),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8f9fa')]),
        ('TOPPADDING',    (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(charge_table)

    # Total Row
    total_data = [["TOTAL AMOUNT DUE", format_currency(bill_data['total_amount'])]]
    total_table = Table(total_data, colWidths=[12*cm, 6*cm])
    total_table.setStyle(TableStyle([
        ('BACKGROUND',  (0, 0), (-1, -1), colors.HexColor('#e74c3c')),
        ('TEXTCOLOR',   (0, 0), (-1, -1), colors.white),
        ('FONTNAME',    (0, 0), (-1, -1), 'Helvetica-Bold'),
        ('FONTSIZE',    (0, 0), (-1, -1), 11),
        ('ALIGN',       (1, 0), (1, -1),  'RIGHT'),
        ('TOPPADDING',  (0, 0), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
    ]))
    story.append(total_table)
    story.append(Spacer(1, 0.5*cm))

    # --- Footer ---
    footer_style = ParagraphStyle('footer', parent=styles['Normal'],
                                   fontSize=8, textColor=colors.grey,
                                   alignment=TA_CENTER)
    story.append(HRFlowable(width="100%", thickness=1, color=colors.lightgrey))
    story.append(Paragraph(
        f"Please pay by {format_date(bill_data['due_date'])} to avoid disconnection. "
        "This is a computer-generated bill and does not require a signature.",
        footer_style
    ))

    doc.build(story)
    return output_path


def generate_receipt_pdf(payment_data, output_path=None):
    """
    Generate a PDF payment receipt.
    payment_data: dict from payment.get_payment_by_receipt()
    Returns file path of generated PDF.
    """
    if not REPORTLAB_AVAILABLE:
        return None

    if output_path is None:
        os.makedirs("reports", exist_ok=True)
        output_path = f"reports/receipt_{payment_data['receipt_number']}.pdf"

    doc    = SimpleDocTemplate(output_path, pagesize=A4,
                                topMargin=2*cm, bottomMargin=2*cm,
                                leftMargin=4*cm, rightMargin=4*cm)
    styles = getSampleStyleSheet()
    story  = []

    title_style = ParagraphStyle('title', parent=styles['Title'],
                                  fontSize=14, alignment=TA_CENTER,
                                  textColor=colors.HexColor('#27ae60'))
    sub_style   = ParagraphStyle('sub', parent=styles['Normal'],
                                  fontSize=9, textColor=colors.grey,
                                  alignment=TA_CENTER)

    story.append(Paragraph(COMPANY_NAME, title_style))
    story.append(Paragraph("PAYMENT RECEIPT", title_style))
    story.append(Paragraph(COMPANY_ADDRESS, sub_style))
    story.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor('#27ae60')))
    story.append(Spacer(1, 0.5*cm))

    receipt_data = [
        ["Receipt Number", str(payment_data['receipt_number'])],
        ["Consumer Name",  str(payment_data['full_name'])],
        ["Meter Number",   str(payment_data['meter_number'])],
        ["Billing Period", str(payment_data['billing_period'])],
        ["Payment Date",   format_date(payment_data['payment_date'])],
        ["Amount Paid",    format_currency(payment_data['amount_paid'])],
        ["Payment Mode",   str(payment_data['payment_mode'])],
        ["Total Bill",     format_currency(payment_data['total_amount'])],
    ]

    table = Table(receipt_data, colWidths=[6*cm, 8*cm])
    table.setStyle(TableStyle([
        ('FONTSIZE',     (0, 0), (-1, -1), 10),
        ('FONTNAME',     (0, 0), (0, -1),  'Helvetica-Bold'),
        ('TEXTCOLOR',    (0, 0), (0, -1),  colors.HexColor('#2c3e50')),
        ('GRID',         (0, 0), (-1, -1), 0.5, colors.lightgrey),
        ('ROWBACKGROUNDS',(0, 0),(-1,-1), [colors.white, colors.HexColor('#f0fff4')]),
        ('TOPPADDING',   (0, 0), (-1, -1), 7),
        ('BOTTOMPADDING',(0, 0), (-1, -1), 7),
    ]))
    story.append(table)
    story.append(Spacer(1, 0.5*cm))

    footer_style = ParagraphStyle('footer', parent=styles['Normal'],
                                   fontSize=8, textColor=colors.grey,
                                   alignment=TA_CENTER)
    story.append(HRFlowable(width="100%", thickness=1, color=colors.lightgrey))
    story.append(Paragraph("Thank you for your payment. Please retain this receipt for your records.", footer_style))

    doc.build(story)
    return output_path
