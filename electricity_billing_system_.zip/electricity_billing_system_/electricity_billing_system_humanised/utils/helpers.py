# helpers.py - small utility functions used throughout the app


from datetime import date
import calendar


def format_currency(amount):
    """Format a float as Indian Rupee string: ₹1,234.56"""
    try:
        return f"₹{float(amount):,.2f}"
    except (ValueError, TypeError):
        return "₹0.00"


def format_date(d):
    """Format a date object as DD-MM-YYYY string."""
    if d is None:
        return "—"
    try:
        return d.strftime("%d-%m-%Y")
    except AttributeError:
        return str(d)


def get_billing_month_str(d=None):
    """Return current (or given) month as YYYY-MM string."""
    if d is None:
        d = date.today()
    return d.strftime("%Y-%m")


def get_month_name(month_num):
    """Convert month number (1-12) to full month name."""
    return calendar.month_name[int(month_num)]


def get_billing_period_label(billing_month_str):
    """
    Convert YYYY-MM to human-readable period label.
    e.g. '2026-05' -> 'May 2026'
    """
    try:
        year, month = billing_month_str.split('-')
        return f"{get_month_name(month)} {year}"
    except Exception:
        return billing_month_str


def days_until_due(due_date):
    """Return number of days until due date (negative if overdue)."""
    if due_date is None:
        return None
    try:
        delta = due_date - date.today()
        return delta.days
    except Exception:
        return None


def get_payment_status_color(status):
    """Return a color tag for payment status display."""
    colors = {
        'Paid'          : '#27ae60',   # green
        'Unpaid'        : '#e74c3c',   # red
        'Partially Paid': '#f39c12'    # orange
    }
    return colors.get(status, '#7f8c8d')


def truncate_text(text, max_len=30):
    """Truncate long text with ellipsis for UI display."""
    if text and len(str(text)) > max_len:
        return str(text)[:max_len - 3] + "..."
    return str(text) if text else ""


def generate_bill_number(bill_id):
    """Format a bill ID as a display bill number: BILL-2026-000123"""
    year = date.today().year
    return f"BILL-{year}-{int(bill_id):06d}"
