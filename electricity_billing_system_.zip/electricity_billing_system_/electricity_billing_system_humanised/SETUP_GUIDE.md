# Electricity Billing System — Complete Setup Guide

Follow these steps in order. Do not skip any step.

---

## STEP 1 — Install Python

1. Go to https://www.python.org/downloads/
2. Click **Download Python 3.x.x**
3. Run the installer
4. **IMPORTANT:** Tick the box that says **"Add Python to PATH"** before clicking Install
5. Click Install Now

To check it worked, open Command Prompt and type:
```
python --version
```
You should see something like `Python 3.11.x`

---

## STEP 2 — Install MySQL

1. Go to https://dev.mysql.com/downloads/installer/
2. Download **MySQL Installer for Windows**
3. Run the installer, choose **Developer Default**
4. During setup it will ask you to set a **root password** — remember this password, you will need it later
5. Also install **MySQL Workbench** from the same installer (it is usually included)

---

## STEP 3 — Install Python Libraries

Open Command Prompt and run these one by one:

```
pip install mysql-connector-python
```
```
pip install reportlab
```

---

## STEP 4 — Setup the Database in MySQL Workbench

### 4.1 — Open MySQL Workbench
- Open MySQL Workbench from the Start Menu
- You will see a box under "MySQL Connections" — click it
- Enter your root password when asked

### 4.2 — Create the database and tables
- Click the **+** icon next to the query tab to open a new query window
- Copy and paste the following SQL and click the ⚡ (Execute) button:

```sql
CREATE DATABASE IF NOT EXISTS electricity_billing_db
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_unicode_ci;

USE electricity_billing_db;

CREATE TABLE IF NOT EXISTS tbl_users (
    user_id        INT           AUTO_INCREMENT PRIMARY KEY,
    username       VARCHAR(50)   NOT NULL UNIQUE,
    password_hash  VARCHAR(255)  NOT NULL,
    full_name      VARCHAR(100)  NOT NULL,
    role           ENUM('Administrator', 'Operator') NOT NULL,
    email          VARCHAR(100),
    created_date   DATE          NOT NULL,
    status         ENUM('Active', 'Inactive') DEFAULT 'Active'
);

CREATE TABLE IF NOT EXISTS tbl_consumers (
    consumer_id      INT           AUTO_INCREMENT PRIMARY KEY,
    full_name        VARCHAR(100)  NOT NULL,
    address          TEXT          NOT NULL,
    contact_number   VARCHAR(15)   NOT NULL,
    email            VARCHAR(100),
    meter_number     VARCHAR(20)   NOT NULL UNIQUE,
    connection_type  ENUM('Domestic', 'Commercial', 'Industrial') NOT NULL,
    sanctioned_load  DECIMAL(6,2)  NOT NULL,
    connection_date  DATE          NOT NULL,
    status           ENUM('Active', 'Inactive') DEFAULT 'Active'
);

CREATE TABLE IF NOT EXISTS tbl_tariffs (
    tariff_id        INT           AUTO_INCREMENT PRIMARY KEY,
    connection_type  ENUM('Domestic', 'Commercial', 'Industrial') NOT NULL,
    slab_from        INT           NOT NULL,
    slab_to          INT,
    rate_per_unit    DECIMAL(6,2)  NOT NULL,
    fixed_charge     DECIMAL(8,2)  NOT NULL DEFAULT 0.00,
    fuel_surcharge   DECIMAL(5,2)  NOT NULL DEFAULT 0.00,
    tax_percentage   DECIMAL(5,2)  NOT NULL DEFAULT 0.00,
    effective_date   DATE          NOT NULL
);

CREATE TABLE IF NOT EXISTS tbl_meter_readings (
    reading_id        INT        AUTO_INCREMENT PRIMARY KEY,
    consumer_id       INT        NOT NULL,
    reading_date      DATE       NOT NULL,
    previous_reading  INT        NOT NULL DEFAULT 0,
    current_reading   INT        NOT NULL,
    units_consumed    INT        NOT NULL,
    billing_month     VARCHAR(7) NOT NULL,
    operator_id       INT        NOT NULL,
    FOREIGN KEY (consumer_id) REFERENCES tbl_consumers(consumer_id),
    FOREIGN KEY (operator_id) REFERENCES tbl_users(user_id),
    UNIQUE KEY uq_consumer_month (consumer_id, billing_month)
);

CREATE TABLE IF NOT EXISTS tbl_bills (
    bill_id          INT            AUTO_INCREMENT PRIMARY KEY,
    consumer_id      INT            NOT NULL,
    reading_id       INT            NOT NULL UNIQUE,
    bill_date        DATE           NOT NULL,
    billing_period   VARCHAR(30)    NOT NULL,
    units_consumed   INT            NOT NULL,
    unit_charge      DECIMAL(10,2)  NOT NULL,
    fixed_charge     DECIMAL(10,2)  NOT NULL DEFAULT 0.00,
    surcharge        DECIMAL(10,2)  NOT NULL DEFAULT 0.00,
    tax_amount       DECIMAL(10,2)  NOT NULL DEFAULT 0.00,
    total_amount     DECIMAL(10,2)  NOT NULL,
    due_date         DATE           NOT NULL,
    payment_status   ENUM('Unpaid', 'Paid', 'Partially Paid') DEFAULT 'Unpaid',
    FOREIGN KEY (consumer_id) REFERENCES tbl_consumers(consumer_id),
    FOREIGN KEY (reading_id)  REFERENCES tbl_meter_readings(reading_id)
);

CREATE TABLE IF NOT EXISTS tbl_payments (
    payment_id      INT            AUTO_INCREMENT PRIMARY KEY,
    bill_id         INT            NOT NULL,
    consumer_id     INT            NOT NULL,
    payment_date    DATE           NOT NULL,
    amount_paid     DECIMAL(10,2)  NOT NULL,
    payment_mode    ENUM('Cash', 'Cheque', 'Online', 'UPI') NOT NULL,
    receipt_number  VARCHAR(20)    NOT NULL UNIQUE,
    operator_id     INT            NOT NULL,
    FOREIGN KEY (bill_id)      REFERENCES tbl_bills(bill_id),
    FOREIGN KEY (consumer_id)  REFERENCES tbl_consumers(consumer_id),
    FOREIGN KEY (operator_id)  REFERENCES tbl_users(user_id)
);
```

You should see all green ticks. Yellow warnings are fine — they just mean the table already exists.

---

### 4.3 — Insert login accounts and sample data
Open a new query tab, paste this and click ⚡:

```sql
USE electricity_billing_db;

SET SQL_SAFE_UPDATES = 0;

-- Login accounts
-- Admin password: Admin@1234
-- Operator password: Operator@123

INSERT INTO tbl_users (username, password_hash, full_name, role, email, created_date, status)
VALUES
('admin',     SHA2('Admin@1234',   256), 'System Administrator', 'Administrator', 'admin@ebilling.com',   CURDATE(), 'Active'),
('operator1', SHA2('Operator@123', 256), 'Rajesh Kumar',         'Operator',      'rajesh@ebilling.com',  CURDATE(), 'Active'),
('operator2', SHA2('Operator@123', 256), 'Sunita Sharma',        'Operator',      'sunita@ebilling.com',  CURDATE(), 'Active');

-- Tariff rates
INSERT INTO tbl_tariffs (connection_type, slab_from, slab_to, rate_per_unit, fixed_charge, fuel_surcharge, tax_percentage, effective_date)
VALUES
('Domestic',    0,    100,  3.00,  50.00,  5.00,  5.00, '2026-01-01'),
('Domestic',    101,  300,  5.00,  50.00,  5.00,  5.00, '2026-01-01'),
('Domestic',    301,  NULL, 7.00,  50.00,  5.00,  5.00, '2026-01-01'),
('Commercial',  0,    200,  6.00,  100.00, 8.00,  10.00,'2026-01-01'),
('Commercial',  201,  NULL, 9.00,  100.00, 8.00,  10.00,'2026-01-01'),
('Industrial',  0,    500,  8.00,  200.00, 10.00, 12.00,'2026-01-01'),
('Industrial',  501,  NULL, 11.00, 200.00, 10.00, 12.00,'2026-01-01');

-- Sample consumers
INSERT INTO tbl_consumers (full_name, address, contact_number, email, meter_number, connection_type, sanctioned_load, connection_date, status)
VALUES
('Ramesh Sharma',       '12 MG Road, Sector 4, New Delhi',          '9876543210', 'ramesh@email.com',  'MTR-001', 'Domestic',   5.00,  '2020-06-15', 'Active'),
('Priya Verma',         '45 Park Street, Lajpat Nagar, New Delhi',  '9876543211', 'priya@email.com',   'MTR-002', 'Domestic',   3.00,  '2019-03-22', 'Active'),
('Suresh Patel',        '8 Gandhi Nagar, Dwarka, New Delhi',        '9876543212', 'suresh@email.com',  'MTR-003', 'Domestic',   4.00,  '2021-01-05', 'Active'),
('Sunrise Enterprises', 'Plot 7, Okhla Industrial Area, New Delhi', '9876543213', 'sunrise@email.com', 'MTR-004', 'Commercial', 25.00, '2018-11-10', 'Active'),
('Metro Textiles Ltd',  'B-12 Naraina, New Delhi',                  '9876543214', 'metro@email.com',   'MTR-005', 'Industrial', 100.00,'2017-07-20', 'Active');
```

All green ticks = success.

---

## STEP 5 — Configure the Project

Open the file `config.py` from the project folder in Notepad or any text editor.

Find this line:
```python
'password': 'your_password_here',
```

Change it to your MySQL root password. For example:
```python
'password': 'mypassword123',
```

Save the file.

---

## STEP 6 — Run the Application

Open Command Prompt, navigate to the project folder:
```
cd C:\Users\YourName\Desktop\electricity_billing_system
```
(Change the path to wherever you saved the project)

Then run:
```
python main.py
```

A login window will open.

---

## Login Credentials

| Role | Username | Password |
|------|----------|----------|
| Administrator | admin | Admin@1234 |
| Operator | operator1 | Operator@123 |
| Operator | operator2 | Operator@123 |

---

## Common Errors and Fixes

### "No module named mysql.connector"
Run: `pip install mysql-connector-python`

### "No module named reportlab"
Run: `pip install reportlab`

### "Cannot connect to database"
- Check your password in `config.py`
- Make sure MySQL service is running (search "Services" in Windows, find MySQL80, make sure it says Running)

### "Invalid username or password" on login
- Make sure you ran Step 4.3 completely
- Check all rows show green ticks in Workbench

### "Operation failed" when registering consumer
- Make sure you ran the tariff INSERT in Step 4.3
- Contact number must be exactly 10 digits
- Meter number must be 3–20 characters, no spaces
- Sanctioned load must be a number like `5` or `2.5`
- Connection date must be in YYYY-MM-DD format like `2026-06-10`

---

## That's it! The app should be running now.
