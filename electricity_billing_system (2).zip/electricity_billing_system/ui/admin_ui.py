# ============================================================
# ui/admin_ui.py
# Admin Panel - User Management & Tariff Configuration
# ============================================================

import tkinter as tk
from tkinter import ttk, messagebox
from assets.styles import COLORS, FONTS
from modules.auth    import (get_all_users, add_user,
                              set_user_status, reset_user_password)
from modules.billing import get_tariff_slabs
from config          import get_connection
from utils.helpers   import format_date


class AdminFrame(tk.Frame):
    def __init__(self, parent, user):
        super().__init__(parent, bg=COLORS['bg_content'])
        self.user = user
        self._build_ui()

    def _build_ui(self):
        tk.Label(self, text="Admin Panel",
                 font=FONTS['heading_medium'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(anchor='w', padx=20, pady=(15, 10))

        nb = ttk.Notebook(self)
        nb.pack(fill='both', expand=True, padx=20, pady=5)

        tab1 = tk.Frame(nb, bg=COLORS['bg_content'])
        tab2 = tk.Frame(nb, bg=COLORS['bg_content'])
        tab3 = tk.Frame(nb, bg=COLORS['bg_content'])
        nb.add(tab1, text="  👥  User Management  ")
        nb.add(tab2, text="  💡  Tariff Management  ")
        nb.add(tab3, text="  🔑  Change Password  ")

        self._build_user_tab(tab1)
        self._build_tariff_tab(tab2)
        self._build_password_tab(tab3)

    # ── User Management ──────────────────────────────────────
    def _build_user_tab(self, parent):
        top = tk.Frame(parent, bg=COLORS['bg_content'])
        top.pack(fill='x', padx=20, pady=15)
        tk.Label(top, text="System Users",
                 font=FONTS['heading_small'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(side='left')
        tk.Button(top, text="＋  Add User",
                  font=FONTS['button'],
                  bg=COLORS['accent_green'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._open_add_user).pack(side='right')
        tk.Button(top, text="🔄 Refresh",
                  font=FONTS['small'],
                  bg=COLORS['accent_blue'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._load_users).pack(side='right', padx=8)

        cols   = ('ID', 'Username', 'Full Name', 'Role', 'Email', 'Created', 'Status')
        widths = [50, 110, 160, 120, 180, 100, 80]
        self.user_tree = ttk.Treeview(parent, columns=cols,
                                       show='headings', selectmode='browse')
        for col, w in zip(cols, widths):
            self.user_tree.heading(col, text=col)
            self.user_tree.column(col, width=w, anchor='center')

        self.user_tree.tag_configure('active',   background='#e8f8f0')
        self.user_tree.tag_configure('inactive', background='#fdf2f2')

        vsb = ttk.Scrollbar(parent, orient='vertical', command=self.user_tree.yview)
        self.user_tree.configure(yscrollcommand=vsb.set)
        self.user_tree.pack(side='left', fill='both', expand=True, padx=(20, 0), pady=5)
        vsb.pack(side='left', fill='y', pady=5)

        btn_frame = tk.Frame(parent, bg=COLORS['bg_content'])
        btn_frame.pack(fill='x', padx=20, pady=8)
        for text, color, cmd in [
            ("✅ Activate",   COLORS['accent_green'],  lambda: self._toggle_user('Active')),
            ("🚫 Deactivate", COLORS['accent_orange'], lambda: self._toggle_user('Inactive')),
            ("🔑 Reset Pwd",  COLORS['accent_blue'],   self._reset_password),
        ]:
            tk.Button(btn_frame, text=text, font=FONTS['small'],
                      bg=color, fg='white', relief='flat', cursor='hand2',
                      command=cmd).pack(side='left', padx=5, ipady=4)

        self._load_users()

    def _load_users(self):
        for row in self.user_tree.get_children():
            self.user_tree.delete(row)
        for u in get_all_users():
            tag = 'active' if u['status'] == 'Active' else 'inactive'
            self.user_tree.insert('', 'end', values=(
                u['user_id'], u['username'], u['full_name'],
                u['role'], u.get('email', ''),
                format_date(u['created_date']), u['status']
            ), tags=(tag,))

    def _get_selected_user_id(self):
        sel = self.user_tree.selection()
        if not sel:
            messagebox.showwarning("No Selection", "Please select a user first.")
            return None
        return self.user_tree.item(sel[0])['values'][0]

    def _toggle_user(self, status):
        uid = self._get_selected_user_id()
        if uid:
            if uid == self.user['user_id']:
                messagebox.showwarning("Not Allowed", "You cannot change your own account status.")
                return
            if set_user_status(uid, status):
                self._load_users()
            else:
                messagebox.showerror("Error", "Could not update user status.")

    def _reset_password(self):
        uid = self._get_selected_user_id()
        if uid:
            _ResetPasswordWindow(self, uid, self.user)

    def _open_add_user(self):
        _AddUserWindow(self, self._load_users)

    # ── Tariff Management ────────────────────────────────────
    def _build_tariff_tab(self, parent):
        top = tk.Frame(parent, bg=COLORS['bg_content'])
        top.pack(fill='x', padx=20, pady=15)
        tk.Label(top, text="Tariff Configuration",
                 font=FONTS['heading_small'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(side='left')

        for ctype in ['Domestic', 'Commercial', 'Industrial']:
            tk.Button(top, text=f"View {ctype}",
                      font=FONTS['small'],
                      bg=COLORS['accent_blue'], fg='white',
                      relief='flat', cursor='hand2',
                      command=lambda t=ctype: self._load_tariff(t)
                      ).pack(side='left', padx=5)

        tk.Button(top, text="＋ Add Slab",
                  font=FONTS['button'],
                  bg=COLORS['accent_green'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._add_tariff_slab).pack(side='right')

        cols   = ('ID', 'Type', 'Slab From', 'Slab To', 'Rate/Unit(₹)',
                  'Fixed(₹)', 'Surcharge(%)', 'Tax(%)', 'Effective Date')
        widths = [50, 100, 85, 85, 100, 90, 100, 70, 110]
        self.tariff_tree = ttk.Treeview(parent, columns=cols,
                                         show='headings', selectmode='browse')
        for col, w in zip(cols, widths):
            self.tariff_tree.heading(col, text=col)
            self.tariff_tree.column(col, width=w, anchor='center')

        vsb = ttk.Scrollbar(parent, orient='vertical', command=self.tariff_tree.yview)
        self.tariff_tree.configure(yscrollcommand=vsb.set)
        self.tariff_tree.pack(side='left', fill='both', expand=True, padx=(20, 0), pady=5)
        vsb.pack(side='left', fill='y', pady=5)
        self._load_tariff('Domestic')

    def _load_tariff(self, connection_type):
        for row in self.tariff_tree.get_children():
            self.tariff_tree.delete(row)
        for t in get_tariff_slabs(connection_type):
            self.tariff_tree.insert('', 'end', values=(
                t['tariff_id'], t['connection_type'],
                t['slab_from'], t['slab_to'] if t['slab_to'] else '∞',
                t['rate_per_unit'], t['fixed_charge'],
                t['fuel_surcharge'], t['tax_percentage'],
                format_date(t['effective_date'])
            ))

    def _add_tariff_slab(self):
        _TariffFormWindow(self)

    # ── Change Password ──────────────────────────────────────
    def _build_password_tab(self, parent):
        frame = tk.Frame(parent, bg=COLORS['bg_content'])
        frame.pack(expand=True)

        tk.Label(frame, text="Change Your Password",
                 font=FONTS['heading_small'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(pady=(30, 20))

        self.pwd_vars = {}
        for label, key, show in [
            ("Current Password:", 'old', True),
            ("New Password:",     'new', True),
            ("Confirm New:",      'confirm', True),
        ]:
            row = tk.Frame(frame, bg=COLORS['bg_content'])
            row.pack(pady=8)
            tk.Label(row, text=label, font=FONTS['body'],
                     bg=COLORS['bg_content'], fg=COLORS['text_dark'],
                     width=18, anchor='w').pack(side='left')
            var = tk.StringVar()
            self.pwd_vars[key] = var
            tk.Entry(row, textvariable=var, font=FONTS['entry'],
                     show='●' if show else '',
                     width=22, relief='solid', bd=1).pack(side='left')

        tk.Button(frame, text="🔑  Update Password",
                  font=FONTS['button'],
                  bg=COLORS['accent_green'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._change_password).pack(pady=20, ipadx=20, ipady=8)

    def _change_password(self):
        old     = self.pwd_vars['old'].get()
        new     = self.pwd_vars['new'].get()
        confirm = self.pwd_vars['confirm'].get()

        if not old or not new or not confirm:
            messagebox.showwarning("Required", "All fields are required.")
            return
        if new != confirm:
            messagebox.showerror("Mismatch", "New passwords do not match.")
            return
        if len(new) < 6:
            messagebox.showwarning("Too Short", "Password must be at least 6 characters.")
            return

        from modules.auth import change_password
        if change_password(self.user['user_id'], old, new):
            messagebox.showinfo("Success", "Password changed successfully.")
            for v in self.pwd_vars.values():
                v.set('')
        else:
            messagebox.showerror("Error", "Current password is incorrect.")


# ── Add User Window ──────────────────────────────────────────
class _AddUserWindow(tk.Toplevel):
    def __init__(self, parent, on_save):
        super().__init__(parent)
        self.on_save = on_save
        self.title("Add New User")
        self.geometry("420x420")
        self.resizable(False, False)
        self.configure(bg=COLORS['bg_content'])
        self.grab_set()
        self._build()

    def _build(self):
        tk.Label(self, text="Add New System User",
                 font=FONTS['heading_small'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(pady=(20, 15))

        form = tk.Frame(self, bg=COLORS['bg_content'])
        form.pack(padx=30, fill='x')

        self.vars = {}
        fields = [('full_name', 'Full Name *'), ('username', 'Username *'),
                  ('password', 'Password *'), ('email', 'Email')]
        for key, label in fields:
            tk.Label(form, text=label, font=FONTS['small_bold'],
                     bg=COLORS['bg_content'], fg=COLORS['text_dark']).pack(anchor='w', pady=(8, 0))
            var = tk.StringVar()
            self.vars[key] = var
            show = '●' if key == 'password' else ''
            tk.Entry(form, textvariable=var, font=FONTS['entry'],
                     show=show, relief='solid', bd=1).pack(fill='x', ipady=4)

        tk.Label(form, text="Role *", font=FONTS['small_bold'],
                 bg=COLORS['bg_content'], fg=COLORS['text_dark']).pack(anchor='w', pady=(8, 0))
        self.role_var = tk.StringVar(value='Operator')
        ttk.Combobox(form, textvariable=self.role_var,
                     values=['Operator', 'Administrator'],
                     state='readonly', font=FONTS['entry']).pack(fill='x', ipady=4)

        btn_frame = tk.Frame(self, bg=COLORS['bg_content'])
        btn_frame.pack(pady=20)
        tk.Button(btn_frame, text="💾 Save",
                  font=FONTS['button'],
                  bg=COLORS['accent_green'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._save).pack(side='left', padx=10, ipadx=20, ipady=6)
        tk.Button(btn_frame, text="✖ Cancel",
                  font=FONTS['button'],
                  bg=COLORS['text_grey'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self.destroy).pack(side='left', padx=10, ipadx=20, ipady=6)

    def _save(self):
        data = {k: v.get().strip() for k, v in self.vars.items()}
        data['role'] = self.role_var.get()
        if not data['full_name'] or not data['username'] or not data['password']:
            messagebox.showerror("Required", "Full name, username and password are required.", parent=self)
            return
        result = add_user(data)
        if isinstance(result, dict) and 'error' in result:
            messagebox.showerror("Error", result['error'], parent=self)
        elif result:
            messagebox.showinfo("Success", f"User '{data['username']}' created.", parent=self)
            self.on_save()
            self.destroy()
        else:
            messagebox.showerror("Error", "Could not create user.", parent=self)


# ── Reset Password Window ────────────────────────────────────
class _ResetPasswordWindow(tk.Toplevel):
    def __init__(self, parent, target_uid, admin_user):
        super().__init__(parent)
        self.target_uid = target_uid
        self.title("Reset User Password")
        self.geometry("360x220")
        self.resizable(False, False)
        self.configure(bg=COLORS['bg_content'])
        self.grab_set()
        self._build()

    def _build(self):
        tk.Label(self, text="Reset User Password",
                 font=FONTS['heading_small'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(pady=(20, 15))

        frame = tk.Frame(self, bg=COLORS['bg_content'])
        frame.pack(padx=30, fill='x')

        tk.Label(frame, text="New Password:", font=FONTS['body'],
                 bg=COLORS['bg_content'], fg=COLORS['text_dark']).pack(anchor='w')
        self.pwd_var = tk.StringVar()
        tk.Entry(frame, textvariable=self.pwd_var, show='●',
                 font=FONTS['entry'], relief='solid', bd=1).pack(fill='x', ipady=4)

        btn_frame = tk.Frame(self, bg=COLORS['bg_content'])
        btn_frame.pack(pady=20)
        tk.Button(btn_frame, text="Reset",
                  font=FONTS['button'],
                  bg=COLORS['accent_red'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._reset).pack(side='left', padx=8, ipadx=20, ipady=6)
        tk.Button(btn_frame, text="Cancel",
                  font=FONTS['button'],
                  bg=COLORS['text_grey'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self.destroy).pack(side='left', padx=8, ipadx=20, ipady=6)

    def _reset(self):
        pwd = self.pwd_var.get().strip()
        if len(pwd) < 6:
            messagebox.showwarning("Too Short", "Password must be at least 6 characters.", parent=self)
            return
        if reset_user_password(self.target_uid, pwd):
            messagebox.showinfo("Success", "Password reset successfully.", parent=self)
            self.destroy()
        else:
            messagebox.showerror("Error", "Could not reset password.", parent=self)


# ── Add Tariff Slab Window ───────────────────────────────────
class _TariffFormWindow(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Add Tariff Slab")
        self.geometry("420x460")
        self.resizable(False, False)
        self.configure(bg=COLORS['bg_content'])
        self.grab_set()
        self._build()

    def _build(self):
        tk.Label(self, text="Add New Tariff Slab",
                 font=FONTS['heading_small'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(pady=(20, 10))

        form = tk.Frame(self, bg=COLORS['bg_content'])
        form.pack(padx=30, fill='x')

        tk.Label(form, text="Connection Type:", font=FONTS['small_bold'],
                 bg=COLORS['bg_content'], fg=COLORS['text_dark']).pack(anchor='w', pady=(8, 0))
        self.ctype_var = tk.StringVar(value='Domestic')
        ttk.Combobox(form, textvariable=self.ctype_var,
                     values=['Domestic', 'Commercial', 'Industrial'],
                     state='readonly', font=FONTS['entry']).pack(fill='x', ipady=4)

        self.vars = {}
        fields = [
            ('slab_from',      'Slab From (units) *'),
            ('slab_to',        'Slab To (leave blank for unlimited)'),
            ('rate_per_unit',  'Rate Per Unit (₹) *'),
            ('fixed_charge',   'Fixed Charge (₹) *'),
            ('fuel_surcharge', 'Fuel Surcharge (%) *'),
            ('tax_percentage', 'Tax Percentage (%) *'),
            ('effective_date', 'Effective Date (YYYY-MM-DD) *'),
        ]
        for key, label in fields:
            tk.Label(form, text=label, font=FONTS['small_bold'],
                     bg=COLORS['bg_content'], fg=COLORS['text_dark']).pack(anchor='w', pady=(6, 0))
            var = tk.StringVar()
            if key == 'effective_date':
                from datetime import date
                var.set(str(date.today()))
            self.vars[key] = var
            tk.Entry(form, textvariable=var, font=FONTS['entry'],
                     relief='solid', bd=1).pack(fill='x', ipady=3)

        btn_frame = tk.Frame(self, bg=COLORS['bg_content'])
        btn_frame.pack(pady=15)
        tk.Button(btn_frame, text="💾 Save",
                  font=FONTS['button'],
                  bg=COLORS['accent_green'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._save).pack(side='left', padx=8, ipadx=15, ipady=6)
        tk.Button(btn_frame, text="✖ Cancel",
                  font=FONTS['button'],
                  bg=COLORS['text_grey'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self.destroy).pack(side='left', padx=8, ipadx=15, ipady=6)

    def _save(self):
        conn = get_connection()
        if not conn:
            messagebox.showerror("DB Error", "Cannot connect to database.", parent=self)
            return
        try:
            cursor = conn.cursor()
            slab_to = self.vars['slab_to'].get().strip() or None
            cursor.execute("""
                INSERT INTO tbl_tariffs
                    (connection_type, slab_from, slab_to, rate_per_unit,
                     fixed_charge, fuel_surcharge, tax_percentage, effective_date)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                self.ctype_var.get(),
                int(self.vars['slab_from'].get()),
                int(slab_to) if slab_to else None,
                float(self.vars['rate_per_unit'].get()),
                float(self.vars['fixed_charge'].get()),
                float(self.vars['fuel_surcharge'].get()),
                float(self.vars['tax_percentage'].get()),
                self.vars['effective_date'].get()
            ))
            conn.commit()
            messagebox.showinfo("Success", "Tariff slab added successfully.", parent=self)
            self.destroy()
        except Exception as e:
            messagebox.showerror("Error", str(e), parent=self)
        finally:
            cursor.close()
            conn.close()
