# ============================================================
# ui/billing_ui.py
# Billing Module - Meter Reading Entry and Bill Generation
# ============================================================

import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date
from assets.styles import COLORS, FONTS
from modules.billing  import (save_meter_reading, calculate_bill,
                               generate_bill, get_bills_by_consumer,
                               get_last_reading, get_bill_by_id)
from modules.consumer import get_consumer_by_meter, get_consumer_by_id
from utils.helpers    import format_currency, format_date, get_billing_month_str


class BillingFrame(tk.Frame):
    def __init__(self, parent, user):
        super().__init__(parent, bg=COLORS['bg_content'])
        self.user = user
        self._build_ui()

    def _build_ui(self):
        tk.Label(self, text="Meter Reading & Bill Generation",
                 font=FONTS['heading_medium'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(anchor='w', padx=20, pady=(15, 10))

        # Tabs
        nb = ttk.Notebook(self)
        nb.pack(fill='both', expand=True, padx=20, pady=5)

        tab1 = tk.Frame(nb, bg=COLORS['bg_content'])
        tab2 = tk.Frame(nb, bg=COLORS['bg_content'])
        nb.add(tab1, text="  📥  Enter Meter Reading  ")
        nb.add(tab2, text="  📋  View Bills  ")

        self._build_reading_tab(tab1)
        self._build_bills_tab(tab2)

    # ── Tab 1: Meter Reading Entry ───────────────────────────
    def _build_reading_tab(self, parent):
        left = tk.Frame(parent, bg=COLORS['bg_content'])
        left.pack(side='left', fill='both', expand=True, padx=20, pady=20)

        # Search consumer
        tk.Label(left, text="Find Consumer",
                 font=FONTS['heading_small'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(anchor='w')

        search_row = tk.Frame(left, bg=COLORS['bg_content'])
        search_row.pack(fill='x', pady=(5, 15))
        tk.Label(search_row, text="Meter / Consumer ID:",
                 font=FONTS['body'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(side='left')
        self.search_var = tk.StringVar()
        tk.Entry(search_row, textvariable=self.search_var,
                 font=FONTS['entry'], width=20,
                 relief='solid', bd=1).pack(side='left', padx=8)
        tk.Button(search_row, text="Search",
                  font=FONTS['button'],
                  bg=COLORS['accent_blue'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._search_consumer).pack(side='left')

        # Consumer info display
        self.info_frame = tk.LabelFrame(left, text=" Consumer Details ",
                                         font=FONTS['body_bold'],
                                         bg=COLORS['bg_content'],
                                         fg=COLORS['text_grey'])
        self.info_frame.pack(fill='x', pady=10)

        self.info_labels = {}
        for field in ['Name', 'Meter No', 'Type', 'Prev. Reading', 'Status']:
            row = tk.Frame(self.info_frame, bg=COLORS['bg_content'])
            row.pack(fill='x', padx=10, pady=3)
            tk.Label(row, text=f"{field}:", font=FONTS['body_bold'],
                     bg=COLORS['bg_content'], fg=COLORS['text_dark'],
                     width=14, anchor='w').pack(side='left')
            lbl = tk.Label(row, text="—", font=FONTS['body'],
                           bg=COLORS['bg_content'], fg=COLORS['text_grey'])
            lbl.pack(side='left')
            self.info_labels[field] = lbl

        # Reading entry
        entry_frame = tk.LabelFrame(left, text=" Enter Reading ",
                                     font=FONTS['body_bold'],
                                     bg=COLORS['bg_content'],
                                     fg=COLORS['text_grey'])
        entry_frame.pack(fill='x', pady=10)

        for label, attr in [("Current Reading:", 'current_var'),
                             ("Billing Month (YYYY-MM):", 'month_var')]:
            row = tk.Frame(entry_frame, bg=COLORS['bg_content'])
            row.pack(fill='x', padx=10, pady=5)
            tk.Label(row, text=label, font=FONTS['body'],
                     bg=COLORS['bg_content'], fg=COLORS['text_dark'],
                     width=24, anchor='w').pack(side='left')
            var = tk.StringVar()
            if attr == 'month_var':
                var.set(get_billing_month_str())
            setattr(self, attr, var)
            tk.Entry(row, textvariable=var, font=FONTS['entry'],
                     width=15, relief='solid', bd=1).pack(side='left', padx=8)

        # Units preview
        preview_row = tk.Frame(entry_frame, bg=COLORS['bg_content'])
        preview_row.pack(fill='x', padx=10, pady=5)
        tk.Label(preview_row, text="Units Consumed:", font=FONTS['body_bold'],
                 bg=COLORS['bg_content'], fg=COLORS['text_dark'],
                 width=24, anchor='w').pack(side='left')
        self.units_lbl = tk.Label(preview_row, text="—",
                                   font=FONTS['heading_small'],
                                   bg=COLORS['bg_content'],
                                   fg=COLORS['accent_red'])
        self.units_lbl.pack(side='left')
        self.current_var.trace('w', self._update_units_preview)

        tk.Button(left, text="⚡  Generate Bill",
                  font=FONTS['button'],
                  bg=COLORS['accent_red'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._generate_bill).pack(pady=10, ipadx=30, ipady=8)

        self.consumer_data = None

    def _search_consumer(self):
        query = self.search_var.get().strip()
        if not query:
            messagebox.showwarning("Input Required", "Enter a meter number or consumer ID.")
            return
        # Try meter number first, then ID
        consumer = get_consumer_by_meter(query)
        if not consumer:
            try:
                consumer = get_consumer_by_id(int(query))
            except ValueError:
                pass
        if not consumer:
            messagebox.showerror("Not Found", f"No consumer found for: {query}")
            return

        self.consumer_data = consumer
        last = get_last_reading(consumer['consumer_id'])
        prev = last['current_reading'] if last else 0

        self.info_labels['Name'].config(text=consumer['full_name'], fg=COLORS['text_dark'])
        self.info_labels['Meter No'].config(text=consumer['meter_number'], fg=COLORS['text_dark'])
        self.info_labels['Type'].config(text=consumer['connection_type'], fg=COLORS['text_dark'])
        self.info_labels['Prev. Reading'].config(text=str(prev), fg=COLORS['accent_blue'])
        status_color = COLORS['status_active'] if consumer['status'] == 'Active' else COLORS['status_inactive']
        self.info_labels['Status'].config(text=consumer['status'], fg=status_color)
        self.prev_reading = prev

    def _update_units_preview(self, *_):
        try:
            current = int(self.current_var.get())
            prev    = getattr(self, 'prev_reading', 0)
            units   = current - prev
            color   = COLORS['accent_green'] if units >= 0 else COLORS['accent_red']
            self.units_lbl.config(text=str(units), fg=color)
        except ValueError:
            self.units_lbl.config(text="—", fg=COLORS['text_grey'])

    def _generate_bill(self):
        if not self.consumer_data:
            messagebox.showwarning("No Consumer", "Please search and select a consumer first.")
            return

        try:
            current = int(self.current_var.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Current reading must be a whole number.")
            return

        billing_month = self.month_var.get().strip()
        consumer_id   = self.consumer_data['consumer_id']

        # Save reading
        result = save_meter_reading(consumer_id, current, billing_month, self.user['user_id'])
        if isinstance(result, dict) and 'error' in result:
            messagebox.showerror("Error", result['error'])
            return

        reading_id = result
        prev       = getattr(self, 'prev_reading', 0)
        units      = current - prev

        # Calculate bill
        bill_data = calculate_bill(units, self.consumer_data['connection_type'])
        if 'error' in bill_data:
            messagebox.showerror("Tariff Error", bill_data['error'])
            return

        # Save bill
        period  = f"{billing_month}"
        bill_id = generate_bill(consumer_id, reading_id, bill_data, period)
        if bill_id is None:
            messagebox.showerror("Error", "Could not save bill. Please try again.")
            return

        # Show bill
        _BillPreviewWindow(self, get_bill_by_id(bill_id), bill_data)

    # ── Tab 2: View Bills ────────────────────────────────────
    def _build_bills_tab(self, parent):
        top = tk.Frame(parent, bg=COLORS['bg_content'])
        top.pack(fill='x', padx=20, pady=15)

        tk.Label(top, text="Search Consumer ID/Meter:",
                 font=FONTS['body'],
                 bg=COLORS['bg_content'],
                 fg=COLORS['text_dark']).pack(side='left')
        self.bill_search_var = tk.StringVar()
        tk.Entry(top, textvariable=self.bill_search_var,
                 font=FONTS['entry'], width=20,
                 relief='solid', bd=1).pack(side='left', padx=8)
        tk.Button(top, text="View Bills",
                  font=FONTS['button'],
                  bg=COLORS['accent_blue'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._load_bills).pack(side='left')

        cols = ('Bill ID', 'Consumer', 'Period', 'Units', 'Total (₹)', 'Due Date', 'Status')
        self.bill_tree = ttk.Treeview(parent, columns=cols,
                                       show='headings', selectmode='browse')
        widths = [70, 180, 100, 70, 110, 100, 110]
        for col, w in zip(cols, widths):
            self.bill_tree.heading(col, text=col)
            self.bill_tree.column(col, width=w, anchor='center')

        self.bill_tree.tag_configure('Paid',          background='#e8f8f0')
        self.bill_tree.tag_configure('Unpaid',        background='#fdf2f2')
        self.bill_tree.tag_configure('Partially Paid',background='#fef9e7')

        vsb = ttk.Scrollbar(parent, orient='vertical', command=self.bill_tree.yview)
        self.bill_tree.configure(yscrollcommand=vsb.set)
        self.bill_tree.pack(side='left', fill='both', expand=True, padx=(20, 0), pady=5)
        vsb.pack(side='left', fill='y', pady=5)

    def _load_bills(self):
        for row in self.bill_tree.get_children():
            self.bill_tree.delete(row)
        query = self.bill_search_var.get().strip()
        if not query:
            messagebox.showwarning("Input Required", "Enter a consumer ID or meter number.")
            return
        consumer = get_consumer_by_meter(query)
        if not consumer:
            try:
                consumer = get_consumer_by_id(int(query))
            except ValueError:
                pass
        if not consumer:
            messagebox.showerror("Not Found", f"No consumer found: {query}")
            return
        for b in get_bills_by_consumer(consumer['consumer_id']):
            self.bill_tree.insert('', 'end', values=(
                b['bill_id'], b['full_name'], b['billing_period'],
                b['units_consumed'], format_currency(b['total_amount']),
                format_date(b['due_date']), b['payment_status']
            ), tags=(b['payment_status'],))


# ── Bill Preview Window ──────────────────────────────────────
class _BillPreviewWindow(tk.Toplevel):
    def __init__(self, parent, bill, bill_data):
        super().__init__(parent)
        self.bill      = bill
        self.bill_data = bill_data
        self.title(f"Bill — {bill['full_name']}")
        self.geometry("500x620")
        self.resizable(False, False)
        self.configure(bg=COLORS['bg_content'])
        self.grab_set()
        self._build()

    def _build(self):
        # Header
        tk.Label(self, text="⚡ ELECTRICITY BILL",
                 font=FONTS['heading_medium'],
                 bg=COLORS['accent_red'], fg='white').pack(fill='x', pady=0, ipady=12)

        frame = tk.Frame(self, bg=COLORS['bg_content'])
        frame.pack(padx=30, pady=15, fill='both', expand=True)

        def row(label, value, bold=False, color=None):
            r = tk.Frame(frame, bg=COLORS['bg_content'])
            r.pack(fill='x', pady=2)
            tk.Label(r, text=f"{label}:", font=FONTS['body_bold'],
                     bg=COLORS['bg_content'], fg=COLORS['text_dark'],
                     width=22, anchor='w').pack(side='left')
            tk.Label(r, text=str(value),
                     font=FONTS['body_bold'] if bold else FONTS['body'],
                     bg=COLORS['bg_content'],
                     fg=color or COLORS['text_dark']).pack(side='left')

        row("Consumer",       self.bill['full_name'])
        row("Meter Number",   self.bill['meter_number'])
        row("Billing Period", self.bill['billing_month'])
        row("Previous Reading", self.bill.get('previous_reading', 0))
        row("Current Reading",  self.bill.get('current_reading', 0))
        row("Units Consumed",   self.bill['units_consumed'], color=COLORS['accent_blue'])

        tk.Frame(frame, bg=COLORS['text_grey'], height=1).pack(fill='x', pady=8)

        row("Unit Charges",   format_currency(self.bill['unit_charge']))
        row("Fixed Charge",   format_currency(self.bill['fixed_charge']))
        row("Fuel Surcharge", format_currency(self.bill['surcharge']))
        row("Tax Amount",     format_currency(self.bill['tax_amount']))

        tk.Frame(frame, bg=COLORS['text_grey'], height=1).pack(fill='x', pady=8)

        row("TOTAL AMOUNT DUE", format_currency(self.bill['total_amount']),
            bold=True, color=COLORS['accent_red'])
        row("Due Date", format_date(self.bill['due_date']))

        # Buttons
        btn_frame = tk.Frame(self, bg=COLORS['bg_content'])
        btn_frame.pack(pady=15)

        tk.Button(btn_frame, text="🖨  Print / Save PDF",
                  font=FONTS['button'],
                  bg=COLORS['accent_blue'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self._export_pdf).pack(side='left', padx=8, ipadx=15, ipady=6)
        tk.Button(btn_frame, text="✖  Close",
                  font=FONTS['button'],
                  bg=COLORS['text_grey'], fg='white',
                  relief='flat', cursor='hand2',
                  command=self.destroy).pack(side='left', padx=8, ipadx=15, ipady=6)

    def _export_pdf(self):
        try:
            from utils.pdf_generator import generate_bill_pdf
            path = generate_bill_pdf(self.bill)
            if path:
                messagebox.showinfo("PDF Saved", f"Bill saved to:\n{path}", parent=self)
            else:
                messagebox.showwarning("PDF Error",
                    "ReportLab not installed.\nRun: pip install reportlab", parent=self)
        except Exception as e:
            messagebox.showerror("Error", str(e), parent=self)
