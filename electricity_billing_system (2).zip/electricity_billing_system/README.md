# ⚡ Electricity Billing System

A complete desktop-based Electricity Billing System built with **Python**, **Tkinter**, and **MySQL**. Developed as a Minor Project for academic submission.

---

## 📋 Features

- 🔐 Secure Login with Role-Based Access Control (Admin / Operator)
- 👤 Consumer Registration and Management
- 📊 Meter Reading Entry and Unit Calculation
- 🧾 Automatic Slab-Based Bill Generation
- 💳 Payment Recording and Receipt Generation
- 📈 Administrative Reports (Billing, Payment, Defaulters, etc.)
- 🗄️ MySQL Database with Full Referential Integrity
- 📄 PDF Bill and Receipt Export

---

## 🛠️ Tech Stack

| Component       | Technology              |
|----------------|-------------------------|
| Language        | Python 3.11+            |
| GUI Framework   | Tkinter                 |
| Database        | MySQL 8.0               |
| PDF Generation  | ReportLab               |
| DB Connector    | mysql-connector-python  |

---

## 📁 Project Structure

```
electricity_billing_system/
│
├── main.py                   # Application entry point
├── config.py                 # Database configuration
├── requirements.txt          # Python dependencies
├── README.md
│
├── database/
│   ├── schema.sql            # Database creation script
│   └── sample_data.sql       # Sample data for testing
│
├── modules/
│   ├── auth.py               # Authentication & password hashing
│   ├── admin.py              # Admin module functions
│   ├── consumer.py           # Consumer CRUD operations
│   ├── billing.py            # Meter reading & bill calculation
│   ├── payment.py            # Payment recording & tracking
│   └── reports.py            # Report generation queries
│
├── ui/
│   ├── login_ui.py           # Login screen
│   ├── dashboard_ui.py       # Dashboard (Admin & Operator)
│   ├── consumer_ui.py        # Consumer management screens
│   ├── billing_ui.py         # Billing & meter reading screens
│   ├── payment_ui.py         # Payment screens
│   └── reports_ui.py         # Report screens
│
├── utils/
│   ├── validators.py         # Input validation functions
│   ├── pdf_generator.py      # Bill & receipt PDF generation
│   └── helpers.py            # General utility functions
│
└── assets/
    └── styles.py             # UI colors, fonts, theme
```

---

## ⚙️ Installation & Setup

### 1. Clone the Repository
```bash
git clone https://github.com/YOUR_USERNAME/electricity-billing-system.git
cd electricity-billing-system
```

### 2. Install Python Dependencies
```bash
pip install -r requirements.txt
```

### 3. Setup MySQL Database
- Open **MySQL Workbench** or **MySQL Command Line**
- Run the schema script:
```sql
source database/schema.sql
```
- Run the sample data script:
```sql
source database/sample_data.sql
```

### 4. Configure Database Connection
Edit `config.py` and update your MySQL credentials:
```python
DB_CONFIG = {
    'host'    : 'localhost',
    'user'    : 'root',
    'password': 'YOUR_PASSWORD',
    'database': 'electricity_billing_db',
    'port'    : 3306
}
```

### 5. Run the Application
```bash
python main.py
```

---

## 🔑 Default Login Credentials

| Role          | Username    | Password      |
|---------------|-------------|---------------|
| Administrator | `admin`     | `Admin@1234`  |
| Operator      | `operator1` | `Operator@123`|

> ⚠️ Change default passwords after first login.

---

## 📊 Tariff Structure (Configurable)

### Domestic
| Slab       | Units     | Rate/Unit |
|------------|-----------|-----------|
| Slab 1     | 0 – 100   | ₹3.00     |
| Slab 2     | 101 – 300 | ₹5.00     |
| Slab 3     | 301+      | ₹7.00     |

### Commercial
| Slab       | Units     | Rate/Unit |
|------------|-----------|-----------|
| Slab 1     | 0 – 200   | ₹6.00     |
| Slab 2     | 201+      | ₹9.00     |

### Industrial
| Slab       | Units     | Rate/Unit |
|------------|-----------|-----------|
| Slab 1     | 0 – 500   | ₹8.00     |
| Slab 2     | 501+      | ₹11.00    |

---

## 📸 Modules Overview

### Admin Module
- User account management
- Tariff configuration
- System settings

### Consumer Module
- Register new consumers
- Search, view, update consumer profiles
- Activate / deactivate accounts

### Billing Module
- Enter monthly meter readings
- Automatic unit and bill calculation
- Generate & print itemized bills

### Payment Module
- Record full / partial payments
- Generate payment receipts
- Track outstanding dues and overdue accounts

### Report Module
- Monthly Billing Report
- Payment Collection Report
- Outstanding Dues Report
- Defaulter List
- Consumer Billing History
- Consumption Summary

---

## 🧪 Testing

130 test cases were executed across all modules:

| Test Type        | Cases | Passed |
|-----------------|-------|--------|
| Unit Testing     | 62    | 62     |
| Integration      | 10    | 10     |
| System Testing   | 7     | 7      |
| UI Testing       | 12    | 12     |
| Boundary Value   | 12    | 12     |
| Negative Testing | 10    | 10     |
| Database Testing | 10    | 10     |
| **Total**        | **130** | **130** |

---

## 📄 License

This project is developed for academic purposes. Free to use and modify with attribution.

---

## 👨‍💻 Author

Developed as a **Minor Project** submission.

> Built with Python 🐍 + MySQL 🗄️ + Tkinter 🖥️
