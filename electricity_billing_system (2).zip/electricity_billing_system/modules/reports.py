# ============================================================
# modules/reports.py
# Report generation - All administrative report queries
# ============================================================

from config import get_connection


def get_monthly_billing_report(year, month):
    """All bills generated in a specific year/month."""
    connection = get_connection()
    if not connection:
        return []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT b.bill_id, c.consumer_id, c.full_name,
                   c.connection_type, b.billing_period,
                   b.units_consumed, b.total_amount, b.payment_status
            FROM tbl_bills b
            JOIN tbl_consumers c ON b.consumer_id = c.consumer_id
            WHERE YEAR(b.bill_date) = %s AND MONTH(b.bill_date) = %s
            ORDER BY c.full_name
        """, (year, month))
        return cursor.fetchall()
    finally:
        cursor.close()
        connection.close()


def get_payment_collection_report(start_date, end_date):
    """All payments received within a date range."""
    connection = get_connection()
    if not connection:
        return []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT p.receipt_number, c.consumer_id, c.full_name,
                   b.billing_period, p.payment_date,
                   p.amount_paid, p.payment_mode
            FROM tbl_payments p
            JOIN tbl_consumers c ON p.consumer_id = c.consumer_id
            JOIN tbl_bills b     ON p.bill_id = b.bill_id
            WHERE p.payment_date BETWEEN %s AND %s
            ORDER BY p.payment_date DESC
        """, (start_date, end_date))
        return cursor.fetchall()
    finally:
        cursor.close()
        connection.close()


def get_outstanding_dues_report():
    """All consumers with unpaid or partially paid bills."""
    connection = get_connection()
    if not connection:
        return []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT c.consumer_id, c.full_name, c.connection_type,
                   c.meter_number, b.bill_id, b.billing_period,
                   b.total_amount, b.due_date, b.payment_status,
                   COALESCE(SUM(p.amount_paid), 0) AS amount_paid,
                   (b.total_amount - COALESCE(SUM(p.amount_paid), 0)) AS balance_due,
                   DATEDIFF(CURDATE(), b.due_date) AS days_overdue
            FROM tbl_bills b
            JOIN tbl_consumers c ON b.consumer_id = c.consumer_id
            LEFT JOIN tbl_payments p ON b.bill_id = p.bill_id
            WHERE b.payment_status != 'Paid'
            GROUP BY b.bill_id
            HAVING balance_due > 0
            ORDER BY balance_due DESC
        """)
        return cursor.fetchall()
    finally:
        cursor.close()
        connection.close()


def get_defaulter_list(min_days_overdue=1):
    """Consumers with bills overdue beyond a threshold."""
    connection = get_connection()
    if not connection:
        return []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT c.consumer_id, c.full_name, c.contact_number,
                   c.connection_type, b.bill_id, b.billing_period,
                   b.total_amount, b.due_date,
                   DATEDIFF(CURDATE(), b.due_date) AS days_overdue
            FROM tbl_bills b
            JOIN tbl_consumers c ON b.consumer_id = c.consumer_id
            WHERE b.payment_status != 'Paid'
              AND b.due_date < CURDATE()
              AND DATEDIFF(CURDATE(), b.due_date) >= %s
            ORDER BY days_overdue DESC
        """, (min_days_overdue,))
        return cursor.fetchall()
    finally:
        cursor.close()
        connection.close()


def get_consumer_billing_history(consumer_id):
    """Complete bill and payment history for a single consumer."""
    connection = get_connection()
    if not connection:
        return []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT b.bill_id, b.billing_period, b.bill_date,
                   b.units_consumed, b.total_amount,
                   b.due_date, b.payment_status,
                   COALESCE(SUM(p.amount_paid), 0) AS total_paid
            FROM tbl_bills b
            LEFT JOIN tbl_payments p ON b.bill_id = p.bill_id
            WHERE b.consumer_id = %s
            GROUP BY b.bill_id
            ORDER BY b.bill_date DESC
        """, (consumer_id,))
        return cursor.fetchall()
    finally:
        cursor.close()
        connection.close()


def get_consumption_summary(year):
    """Month-wise consumption summary by connection type for a year."""
    connection = get_connection()
    if not connection:
        return []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT MONTH(b.bill_date)     AS month,
                   c.connection_type,
                   SUM(b.units_consumed)  AS total_units,
                   COUNT(b.bill_id)       AS total_bills,
                   SUM(b.total_amount)    AS total_amount
            FROM tbl_bills b
            JOIN tbl_consumers c ON b.consumer_id = c.consumer_id
            WHERE YEAR(b.bill_date) = %s
            GROUP BY MONTH(b.bill_date), c.connection_type
            ORDER BY MONTH(b.bill_date)
        """, (year,))
        return cursor.fetchall()
    finally:
        cursor.close()
        connection.close()
