# ============================================================
# modules/auth.py
# Authentication module - Login and password management
# ============================================================

import hashlib
from config import get_connection


def hash_password(password):
    """Hash a plain text password using SHA-256."""
    return hashlib.sha256(password.encode()).hexdigest()


def authenticate_user(username, password):
    """
    Validate login credentials against the database.
    Returns user dict on success, None on failure,
    or {'error': message} for inactive accounts.
    """
    connection = get_connection()
    if not connection:
        return {'error': 'Cannot connect to database. Check config.py.'}

    try:
        cursor = connection.cursor(dictionary=True)
        hashed = hash_password(password)

        query = """
            SELECT user_id, username, full_name, role, status
            FROM tbl_users
            WHERE username = %s AND password_hash = %s
        """
        cursor.execute(query, (username, hashed))
        user = cursor.fetchone()

        if not user:
            return None
        if user['status'] == 'Inactive':
            return {'error': 'Your account has been disabled. Contact administrator.'}

        return user

    except Exception as e:
        print(f"[AUTH ERROR] {e}")
        return None
    finally:
        cursor.close()
        connection.close()


def change_password(user_id, old_password, new_password):
    """
    Change user password after verifying the old one.
    Returns True on success, False otherwise.
    """
    connection = get_connection()
    if not connection:
        return False

    try:
        cursor = connection.cursor()
        old_hash = hash_password(old_password)
        new_hash = hash_password(new_password)

        cursor.execute(
            "SELECT user_id FROM tbl_users WHERE user_id = %s AND password_hash = %s",
            (user_id, old_hash)
        )
        if not cursor.fetchone():
            return False

        cursor.execute(
            "UPDATE tbl_users SET password_hash = %s WHERE user_id = %s",
            (new_hash, user_id)
        )
        connection.commit()
        return True

    except Exception as e:
        print(f"[AUTH ERROR] change_password: {e}")
        return False
    finally:
        cursor.close()
        connection.close()


def get_all_users():
    """Return all system user accounts."""
    connection = get_connection()
    if not connection:
        return []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute(
            "SELECT user_id, username, full_name, role, email, created_date, status FROM tbl_users ORDER BY full_name"
        )
        return cursor.fetchall()
    finally:
        cursor.close()
        connection.close()


def add_user(data):
    """Create a new system user. Returns user_id or error dict."""
    connection = get_connection()
    if not connection:
        return None
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT user_id FROM tbl_users WHERE username = %s", (data['username'],))
        if cursor.fetchone():
            return {'error': 'Username already exists.'}

        from datetime import date
        cursor.execute("""
            INSERT INTO tbl_users (username, password_hash, full_name, role, email, created_date, status)
            VALUES (%s, %s, %s, %s, %s, %s, 'Active')
        """, (
            data['username'],
            hash_password(data['password']),
            data['full_name'],
            data['role'],
            data.get('email', ''),
            date.today()
        ))
        connection.commit()
        return cursor.lastrowid
    except Exception as e:
        connection.rollback()
        print(f"[AUTH ERROR] add_user: {e}")
        return None
    finally:
        cursor.close()
        connection.close()


def set_user_status(user_id, status):
    """Activate or deactivate a user account."""
    connection = get_connection()
    if not connection:
        return False
    try:
        cursor = connection.cursor()
        cursor.execute(
            "UPDATE tbl_users SET status = %s WHERE user_id = %s",
            (status, user_id)
        )
        connection.commit()
        return True
    except Exception as e:
        print(f"[AUTH ERROR] set_user_status: {e}")
        return False
    finally:
        cursor.close()
        connection.close()


def reset_user_password(user_id, new_password):
    """Admin resets another user's password."""
    connection = get_connection()
    if not connection:
        return False
    try:
        cursor = connection.cursor()
        cursor.execute(
            "UPDATE tbl_users SET password_hash = %s WHERE user_id = %s",
            (hash_password(new_password), user_id)
        )
        connection.commit()
        return True
    except Exception as e:
        print(f"[AUTH ERROR] reset_password: {e}")
        return False
    finally:
        cursor.close()
        connection.close()
