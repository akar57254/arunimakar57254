# ============================================================
# modules/billing.py
# Billing module - Meter reading and bill calculation engine
# ============================================================

from datetime import date, timedelta
from config import get_connection, BILL_DUE_DAYS


def get_last_reading(consumer_id):
    """Return the most recent meter reading for a consumer."""
    connection = get_connection()
    if not connection:
        return None
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT * FROM tbl_meter_readings
            WHERE consumer_id = %s
            ORDER BY reading_date DESC
            LIMIT 1
        """, (consumer_id,))
        return cursor.fetchone()
    finally:
        cursor.close()
        connection.close()


def save_meter_reading(consumer_id, current_reading, billing_month, operator_id):
    """
    Save a new meter reading.
    Returns reading_id on success or error dict on failure.
    """
    connection = get_connection()
    if not connection:
        return {'error': 'Database connection failed.'}
    try:
        cursor = connection.cursor(dictionary=True)

        # Check consumer is active
        cursor.execute(
            "SELECT status FROM tbl_consumers WHERE consumer_id = %s",
            (consumer_id,)
        )
        consumer = cursor.fetchone()
        if not consumer or consumer['status'] == 'Inactive':
            return {'error': 'Cannot record reading for an inactive consumer account.'}

        # Duplicate billing month check
        cursor.execute("""
            SELECT reading_id FROM tbl_meter_readings
            WHERE consumer_id = %s AND billing_month = %s
        """, (consumer_id, billing_month))
        if cursor.fetchone():
            return {'error': f'A reading for {billing_month} already exists for this consumer.'}

        # Get previous reading
        last = get_last_reading(consumer_id)
        previous_reading = last['current_reading'] if last else 0
        units_consumed   = current_reading - previous_reading

        if units_consumed < 0:
            return {'error': f'Current reading ({current_reading}) cannot be less than previous reading ({previous_reading}).'}

        cursor.execute("""
            INSERT INTO tbl_meter_readings
                (consumer_id, reading_date, previous_reading,
                 current_reading, units_consumed, billing_month, operator_id)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (
            consumer_id, date.today(), previous_reading,
            current_reading, units_consumed, billing_month, operator_id
        ))
        connection.commit()
        return cursor.lastrowid

    except Exception as e:
        connection.rollback()
        print(f"[BILLING ERROR] save_reading: {e}")
        return {'error': str(e)}
    finally:
        cursor.close()
        connection.close()


def get_tariff_slabs(connection_type):
    """Return all active tariff slabs for a connection type."""
    connection = get_connection()
    if not connection:
        return []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT * FROM tbl_tariffs
            WHERE connection_type = %s
            ORDER BY slab_from ASC
        """, (connection_type,))
        return cursor.fetchall()
    finally:
        cursor.close()
        connection.close()


def calculate_bill(units_consumed, connection_type):
    """
    Calculate a complete bill breakdown using slab-based tariff.
    Returns dict with all charge components, or error dict.
    """
    slabs = get_tariff_slabs(connection_type)
    if not slabs:
        return {'error': f'No tariff configured for connection type: {connection_type}'}

    unit_charge    = 0.0
    remaining      = units_consumed
    fixed_charge   = float(slabs[0]['fixed_charge'])
    fuel_surcharge = float(slabs[0]['fuel_surcharge'])
    tax_percentage = float(slabs[0]['tax_percentage'])

    slab_breakdown = []

    for slab in slabs:
        if remaining <= 0:
            break

        slab_from = slab['slab_from']
        slab_to   = slab['slab_to']
        rate      = float(slab['rate_per_unit'])

        if slab_to is None:
            units_in_slab = remaining
        else:
            slab_capacity = slab_to - slab_from + 1
            units_in_slab = min(remaining, slab_capacity)

        charge = units_in_slab * rate
        unit_charge += charge
        remaining   -= units_in_slab

        slab_breakdown.append({
            'slab_from'    : slab_from,
            'slab_to'      : slab_to,
            'units'        : units_in_slab,
            'rate'         : rate,
            'charge'       : round(charge, 2)
        })

    surcharge_amount = round(unit_charge * (fuel_surcharge / 100), 2)
    subtotal         = round(unit_charge + fixed_charge + surcharge_amount, 2)
    tax_amount       = round(subtotal * (tax_percentage / 100), 2)
    total_amount     = round(subtotal + tax_amount, 2)

    return {
        'units_consumed'  : units_consumed,
        'unit_charge'     : round(unit_charge, 2),
        'fixed_charge'    : fixed_charge,
        'surcharge'       : surcharge_amount,
        'tax_amount'      : tax_amount,
        'total_amount'    : total_amount,
        'slab_breakdown'  : slab_breakdown,
        'fuel_surcharge_pct': fuel_surcharge,
        'tax_percentage'  : tax_percentage
    }


def generate_bill(consumer_id, reading_id, bill_data, billing_period):
    """
    Save a generated bill to the database.
    Returns bill_id on success, None on failure.
    """
    connection = get_connection()
    if not connection:
        return None
    try:
        cursor = connection.cursor()
        due_date = date.today() + timedelta(days=BILL_DUE_DAYS)

        cursor.execute("""
            INSERT INTO tbl_bills
                (consumer_id, reading_id, bill_date, billing_period,
                 units_consumed, unit_charge, fixed_charge,
                 surcharge, tax_amount, total_amount,
                 due_date, payment_status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'Unpaid')
        """, (
            consumer_id, reading_id, date.today(), billing_period,
            bill_data['units_consumed'],
            bill_data['unit_charge'],
            bill_data['fixed_charge'],
            bill_data['surcharge'],
            bill_data['tax_amount'],
            bill_data['total_amount'],
            due_date
        ))
        connection.commit()
        return cursor.lastrowid

    except Exception as e:
        connection.rollback()
        print(f"[BILLING ERROR] generate_bill: {e}")
        return None
    finally:
        cursor.close()
        connection.close()


def get_bill_by_id(bill_id):
    """Fetch a bill by its ID with consumer details."""
    connection = get_connection()
    if not connection:
        return None
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT b.*, c.full_name, c.address, c.meter_number,
                   c.connection_type, c.contact_number,
                   r.previous_reading, r.current_reading, r.billing_month
            FROM tbl_bills b
            JOIN tbl_consumers c ON b.consumer_id = c.consumer_id
            JOIN tbl_meter_readings r ON b.reading_id = r.reading_id
            WHERE b.bill_id = %s
        """, (bill_id,))
        return cursor.fetchone()
    finally:
        cursor.close()
        connection.close()


def get_bills_by_consumer(consumer_id):
    """Return all bills for a specific consumer."""
    connection = get_connection()
    if not connection:
        return []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT b.*, c.full_name, c.meter_number
            FROM tbl_bills b
            JOIN tbl_consumers c ON b.consumer_id = c.consumer_id
            WHERE b.consumer_id = %s
            ORDER BY b.bill_date DESC
        """, (consumer_id,))
        return cursor.fetchall()
    finally:
        cursor.close()
        connection.close()


def get_reading_history(consumer_id):
    """Return all meter readings for a consumer."""
    connection = get_connection()
    if not connection:
        return []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT * FROM tbl_meter_readings
            WHERE consumer_id = %s
            ORDER BY reading_date DESC
        """, (consumer_id,))
        return cursor.fetchall()
    finally:
        cursor.close()
        connection.close()


def get_monthly_bill_count():
    """Return number of bills generated this calendar month."""
    connection = get_connection()
    if not connection:
        return 0
    try:
        cursor = connection.cursor()
        today = date.today()
        cursor.execute("""
            SELECT COUNT(*) FROM tbl_bills
            WHERE YEAR(bill_date) = %s AND MONTH(bill_date) = %s
        """, (today.year, today.month))
        return cursor.fetchone()[0]
    finally:
        cursor.close()
        connection.close()


def get_monthly_revenue():
    """Return total amount billed this calendar month."""
    connection = get_connection()
    if not connection:
        return 0.0
    try:
        cursor = connection.cursor()
        today = date.today()
        cursor.execute("""
            SELECT COALESCE(SUM(total_amount), 0)
            FROM tbl_bills
            WHERE YEAR(bill_date) = %s AND MONTH(bill_date) = %s
        """, (today.year, today.month))
        return float(cursor.fetchone()[0])
    finally:
        cursor.close()
        connection.close()
