# ============================================================
# modules/consumer.py
# Consumer management - CRUD operations
# ============================================================

from config import get_connection


def register_consumer(data):
    """
    Register a new consumer.
    Returns new consumer_id on success, or error dict.
    """
    connection = get_connection()
    if not connection:
        return None
    try:
        cursor = connection.cursor()

        # Check duplicate meter number
        cursor.execute(
            "SELECT consumer_id FROM tbl_consumers WHERE meter_number = %s",
            (data['meter_number'],)
        )
        if cursor.fetchone():
            return {'error': f"Meter number '{data['meter_number']}' is already registered."}

        cursor.execute("""
            INSERT INTO tbl_consumers
                (full_name, address, contact_number, email,
                 meter_number, connection_type, sanctioned_load,
                 connection_date, status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'Active')
        """, (
            data['full_name'],
            data['address'],
            data['contact_number'],
            data.get('email', ''),
            data['meter_number'],
            data['connection_type'],
            data['sanctioned_load'],
            data['connection_date']
        ))
        connection.commit()
        return cursor.lastrowid

    except Exception as e:
        connection.rollback()
        print(f"[CONSUMER ERROR] register: {e}")
        return None
    finally:
        cursor.close()
        connection.close()


def get_consumer_by_id(consumer_id):
    """Fetch a consumer by their ID."""
    connection = get_connection()
    if not connection:
        return None
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM tbl_consumers WHERE consumer_id = %s", (consumer_id,))
        return cursor.fetchone()
    finally:
        cursor.close()
        connection.close()


def get_consumer_by_meter(meter_number):
    """Fetch a consumer by meter number."""
    connection = get_connection()
    if not connection:
        return None
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM tbl_consumers WHERE meter_number = %s", (meter_number,))
        return cursor.fetchone()
    finally:
        cursor.close()
        connection.close()


def get_all_consumers(status_filter=None):
    """Return all consumers, optionally filtered by status."""
    connection = get_connection()
    if not connection:
        return []
    try:
        cursor = connection.cursor(dictionary=True)
        if status_filter:
            cursor.execute(
                "SELECT * FROM tbl_consumers WHERE status = %s ORDER BY full_name",
                (status_filter,)
            )
        else:
            cursor.execute("SELECT * FROM tbl_consumers ORDER BY full_name")
        return cursor.fetchall()
    finally:
        cursor.close()
        connection.close()


def search_consumers(keyword):
    """Search consumers by name, meter number, or address."""
    connection = get_connection()
    if not connection:
        return []
    try:
        cursor = connection.cursor(dictionary=True)
        term = f"%{keyword}%"
        cursor.execute("""
            SELECT consumer_id, full_name, meter_number,
                   connection_type, contact_number, status
            FROM tbl_consumers
            WHERE full_name     LIKE %s
               OR meter_number  LIKE %s
               OR address       LIKE %s
            ORDER BY full_name
        """, (term, term, term))
        return cursor.fetchall()
    finally:
        cursor.close()
        connection.close()


def update_consumer(consumer_id, data):
    """Update an existing consumer's editable details."""
    connection = get_connection()
    if not connection:
        return False
    try:
        cursor = connection.cursor()
        cursor.execute("""
            UPDATE tbl_consumers
            SET address         = %s,
                contact_number  = %s,
                email           = %s,
                connection_type = %s,
                sanctioned_load = %s
            WHERE consumer_id = %s
        """, (
            data['address'],
            data['contact_number'],
            data.get('email', ''),
            data['connection_type'],
            data['sanctioned_load'],
            consumer_id
        ))
        connection.commit()
        return True
    except Exception as e:
        connection.rollback()
        print(f"[CONSUMER ERROR] update: {e}")
        return False
    finally:
        cursor.close()
        connection.close()


def set_consumer_status(consumer_id, status):
    """Activate or deactivate a consumer account."""
    connection = get_connection()
    if not connection:
        return False
    try:
        cursor = connection.cursor()
        cursor.execute(
            "UPDATE tbl_consumers SET status = %s WHERE consumer_id = %s",
            (status, consumer_id)
        )
        connection.commit()
        return True
    except Exception as e:
        print(f"[CONSUMER ERROR] set_status: {e}")
        return False
    finally:
        cursor.close()
        connection.close()


def get_consumer_count():
    """Return total number of active consumers."""
    connection = get_connection()
    if not connection:
        return 0
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT COUNT(*) FROM tbl_consumers WHERE status = 'Active'")
        return cursor.fetchone()[0]
    finally:
        cursor.close()
        connection.close()
