# ============================================================
# modules/payment.py
# Payment module - Recording payments and tracking dues
# ============================================================

from datetime import date
from config import get_connection


def get_outstanding_bills(consumer_id):
    """Return all unpaid or partially paid bills for a consumer."""
    connection = get_connection()
    if not connection:
        return []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT b.bill_id, b.billing_period, b.total_amount,
                   b.due_date, b.payment_status,
                   COALESCE(SUM(p.amount_paid), 0)           AS amount_paid,
                   (b.total_amount - COALESCE(SUM(p.amount_paid), 0)) AS balance_due
            FROM tbl_bills b
            LEFT JOIN tbl_payments p ON b.bill_id = p.bill_id
            WHERE b.consumer_id = %s AND b.payment_status != 'Paid'
            GROUP BY b.bill_id
            ORDER BY b.bill_date ASC
        """, (consumer_id,))
        return cursor.fetchall()
    finally:
        cursor.close()
        connection.close()


def generate_receipt_number():
    """Generate a unique sequential receipt number: RCP-YYYY-MM-NNNNN."""
    connection = get_connection()
    if not connection:
        return None
    try:
        cursor = connection.cursor()
        today  = date.today()
        prefix = f"RCP-{today.year}-{today.month:02d}-"
        cursor.execute(
            "SELECT COUNT(*) FROM tbl_payments WHERE receipt_number LIKE %s",
            (f"{prefix}%",)
        )
        count = cursor.fetchone()[0]
        return f"{prefix}{(count + 1):05d}"
    finally:
        cursor.close()
        connection.close()


def record_payment(bill_id, consumer_id, amount_paid, payment_mode, operator_id):
    """
    Record a payment transaction.
    Returns receipt_number on success, or error dict on failure.
    """
    connection = get_connection()
    if not connection:
        return {'error': 'Database connection failed.'}
    try:
        cursor = connection.cursor(dictionary=True)

        # Validate bill exists
        cursor.execute(
            "SELECT total_amount, payment_status FROM tbl_bills WHERE bill_id = %s",
            (bill_id,)
        )
        bill = cursor.fetchone()
        if not bill:
            return {'error': 'Bill not found.'}

        # Get amount already paid
        cursor.execute(
            "SELECT COALESCE(SUM(amount_paid), 0) AS paid FROM tbl_payments WHERE bill_id = %s",
            (bill_id,)
        )
        already_paid = float(cursor.fetchone()['paid'])
        balance_due  = float(bill['total_amount']) - already_paid

        if amount_paid <= 0:
            return {'error': 'Payment amount must be greater than zero.'}
        if amount_paid > balance_due + 0.01:   # small float tolerance
            return {'error': f'Amount ₹{amount_paid:.2f} exceeds balance due ₹{balance_due:.2f}.'}

        receipt_number = generate_receipt_number()

        cursor.execute("""
            INSERT INTO tbl_payments
                (bill_id, consumer_id, payment_date, amount_paid,
                 payment_mode, receipt_number, operator_id)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (
            bill_id, consumer_id, date.today(),
            amount_paid, payment_mode, receipt_number, operator_id
        ))

        # Update bill payment status
        new_paid_total = already_paid + amount_paid
        if new_paid_total >= float(bill['total_amount']) - 0.01:
            new_status = 'Paid'
        else:
            new_status = 'Partially Paid'

        cursor.execute(
            "UPDATE tbl_bills SET payment_status = %s WHERE bill_id = %s",
            (new_status, bill_id)
        )
        connection.commit()
        return receipt_number

    except Exception as e:
        connection.rollback()
        print(f"[PAYMENT ERROR] record_payment: {e}")
        return {'error': str(e)}
    finally:
        cursor.close()
        connection.close()


def get_payment_by_receipt(receipt_number):
    """Fetch a payment record by receipt number."""
    connection = get_connection()
    if not connection:
        return None
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT p.*, c.full_name, c.meter_number,
                   b.billing_period, b.total_amount
            FROM tbl_payments p
            JOIN tbl_consumers c ON p.consumer_id = c.consumer_id
            JOIN tbl_bills b ON p.bill_id = b.bill_id
            WHERE p.receipt_number = %s
        """, (receipt_number,))
        return cursor.fetchone()
    finally:
        cursor.close()
        connection.close()


def get_payment_history(consumer_id):
    """Return complete payment history for a consumer."""
    connection = get_connection()
    if not connection:
        return []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT p.payment_id, p.receipt_number, p.payment_date,
                   p.amount_paid, p.payment_mode,
                   b.billing_period, b.total_amount
            FROM tbl_payments p
            JOIN tbl_bills b ON p.bill_id = b.bill_id
            WHERE p.consumer_id = %s
            ORDER BY p.payment_date DESC
        """, (consumer_id,))
        return cursor.fetchall()
    finally:
        cursor.close()
        connection.close()


def get_all_overdue_accounts():
    """Return all consumer accounts with overdue unpaid bills."""
    connection = get_connection()
    if not connection:
        return []
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT c.consumer_id, c.full_name, c.meter_number,
                   c.connection_type,
                   b.bill_id, b.billing_period,
                   b.total_amount, b.due_date,
                   DATEDIFF(CURDATE(), b.due_date) AS days_overdue
            FROM tbl_bills b
            JOIN tbl_consumers c ON b.consumer_id = c.consumer_id
            WHERE b.payment_status != 'Paid'
              AND b.due_date < CURDATE()
            ORDER BY days_overdue DESC
        """)
        return cursor.fetchall()
    finally:
        cursor.close()
        connection.close()


def get_total_outstanding():
    """Return total outstanding dues across all consumers."""
    connection = get_connection()
    if not connection:
        return 0.0
    try:
        cursor = connection.cursor()
        cursor.execute("""
            SELECT COALESCE(
                SUM(b.total_amount - COALESCE(p.paid, 0)), 0
            ) AS total_outstanding
            FROM tbl_bills b
            LEFT JOIN (
                SELECT bill_id, SUM(amount_paid) AS paid
                FROM tbl_payments GROUP BY bill_id
            ) p ON b.bill_id = p.bill_id
            WHERE b.payment_status != 'Paid'
        """)
        return float(cursor.fetchone()[0])
    finally:
        cursor.close()
        connection.close()


def get_overdue_count():
    """Return count of overdue unpaid accounts."""
    connection = get_connection()
    if not connection:
        return 0
    try:
        cursor = connection.cursor()
        cursor.execute("""
            SELECT COUNT(*) FROM tbl_bills
            WHERE payment_status != 'Paid' AND due_date < CURDATE()
        """)
        return cursor.fetchone()[0]
    finally:
        cursor.close()
        connection.close()
