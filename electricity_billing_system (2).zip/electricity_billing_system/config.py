# ============================================================
# config.py
# Database Configuration for Electricity Billing System
# ============================================================

DB_CONFIG = {
    'host'    : 'localhost',
    'user'    : 'root',
    'password': 'your_password_here',   # <-- Change this
    'database': 'electricity_billing_db',
    'port'    : 3306
}

# Application Settings
APP_TITLE        = "Electricity Billing System"
APP_VERSION      = "1.0.0"
BILL_DUE_DAYS    = 15     # Days after bill date until payment is due
COMPANY_NAME     = "City Electricity Distribution Board"
COMPANY_ADDRESS  = "123 Power House Road, New Delhi - 110001"
COMPANY_PHONE    = "+91-11-12345678"
COMPANY_EMAIL    = "billing@cedb.gov.in"


def get_connection():
    """
    Establishes and returns a MySQL database connection.
    Returns None if connection fails.
    """
    import mysql.connector
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        return connection
    except mysql.connector.Error as e:
        print(f"[DB ERROR] Could not connect to database: {e}")
        return None
