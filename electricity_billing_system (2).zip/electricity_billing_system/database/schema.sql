-- ============================================================
-- schema.sql
-- Electricity Billing System - Complete Database Schema
-- Run this file in MySQL before starting the application
-- ============================================================

CREATE DATABASE IF NOT EXISTS electricity_billing_db
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_unicode_ci;

USE electricity_billing_db;

-- ============================================================
-- TABLE 1: tbl_users
-- ============================================================
CREATE TABLE IF NOT EXISTS tbl_users (
    user_id        INT           AUTO_INCREMENT PRIMARY KEY,
    username       VARCHAR(50)   NOT NULL UNIQUE,
    password_hash  VARCHAR(255)  NOT NULL,
    full_name      VARCHAR(100)  NOT NULL,
    role           ENUM('Administrator', 'Operator') NOT NULL,
    email          VARCHAR(100),
    created_date   DATE          NOT NULL,
    status         ENUM('Active', 'Inactive') DEFAULT 'Active',
    INDEX idx_username (username),
    INDEX idx_role     (role)
);

-- ============================================================
-- TABLE 2: tbl_consumers
-- ============================================================
CREATE TABLE IF NOT EXISTS tbl_consumers (
    consumer_id      INT           AUTO_INCREMENT PRIMARY KEY,
    full_name        VARCHAR(100)  NOT NULL,
    address          TEXT          NOT NULL,
    contact_number   VARCHAR(15)   NOT NULL,
    email            VARCHAR(100),
    meter_number     VARCHAR(20)   NOT NULL UNIQUE,
    connection_type  ENUM('Domestic', 'Commercial', 'Industrial') NOT NULL,
    sanctioned_load  DECIMAL(6,2)  NOT NULL,
    connection_date  DATE          NOT NULL,
    status           ENUM('Active', 'Inactive') DEFAULT 'Active',
    INDEX idx_meter_number    (meter_number),
    INDEX idx_connection_type (connection_type),
    INDEX idx_status          (status)
);

-- ============================================================
-- TABLE 3: tbl_tariffs
-- ============================================================
CREATE TABLE IF NOT EXISTS tbl_tariffs (
    tariff_id        INT           AUTO_INCREMENT PRIMARY KEY,
    connection_type  ENUM('Domestic', 'Commercial', 'Industrial') NOT NULL,
    slab_from        INT           NOT NULL,
    slab_to          INT,
    rate_per_unit    DECIMAL(6,2)  NOT NULL,
    fixed_charge     DECIMAL(8,2)  NOT NULL DEFAULT 0.00,
    fuel_surcharge   DECIMAL(5,2)  NOT NULL DEFAULT 0.00,
    tax_percentage   DECIMAL(5,2)  NOT NULL DEFAULT 0.00,
    effective_date   DATE          NOT NULL,
    INDEX idx_connection_type (connection_type),
    INDEX idx_effective_date  (effective_date)
);

-- ============================================================
-- TABLE 4: tbl_meter_readings
-- ============================================================
CREATE TABLE IF NOT EXISTS tbl_meter_readings (
    reading_id        INT        AUTO_INCREMENT PRIMARY KEY,
    consumer_id       INT        NOT NULL,
    reading_date      DATE       NOT NULL,
    previous_reading  INT        NOT NULL DEFAULT 0,
    current_reading   INT        NOT NULL,
    units_consumed    INT        NOT NULL,
    billing_month     VARCHAR(7) NOT NULL,
    operator_id       INT        NOT NULL,
    FOREIGN KEY (consumer_id)
        REFERENCES tbl_consumers(consumer_id)
        ON DELETE RESTRICT,
    FOREIGN KEY (operator_id)
        REFERENCES tbl_users(user_id)
        ON DELETE RESTRICT,
    UNIQUE KEY uq_consumer_month (consumer_id, billing_month),
    INDEX idx_consumer_id   (consumer_id),
    INDEX idx_billing_month (billing_month)
);

-- ============================================================
-- TABLE 5: tbl_bills
-- ============================================================
CREATE TABLE IF NOT EXISTS tbl_bills (
    bill_id          INT            AUTO_INCREMENT PRIMARY KEY,
    consumer_id      INT            NOT NULL,
    reading_id       INT            NOT NULL UNIQUE,
    bill_date        DATE           NOT NULL,
    billing_period   VARCHAR(30)    NOT NULL,
    units_consumed   INT            NOT NULL,
    unit_charge      DECIMAL(10,2)  NOT NULL,
    fixed_charge     DECIMAL(10,2)  NOT NULL DEFAULT 0.00,
    surcharge        DECIMAL(10,2)  NOT NULL DEFAULT 0.00,
    tax_amount       DECIMAL(10,2)  NOT NULL DEFAULT 0.00,
    total_amount     DECIMAL(10,2)  NOT NULL,
    due_date         DATE           NOT NULL,
    payment_status   ENUM('Unpaid', 'Paid', 'Partially Paid') DEFAULT 'Unpaid',
    FOREIGN KEY (consumer_id)
        REFERENCES tbl_consumers(consumer_id)
        ON DELETE RESTRICT,
    FOREIGN KEY (reading_id)
        REFERENCES tbl_meter_readings(reading_id)
        ON DELETE RESTRICT,
    INDEX idx_consumer_id    (consumer_id),
    INDEX idx_bill_date      (bill_date),
    INDEX idx_payment_status (payment_status),
    INDEX idx_due_date       (due_date)
);

-- ============================================================
-- TABLE 6: tbl_payments
-- ============================================================
CREATE TABLE IF NOT EXISTS tbl_payments (
    payment_id      INT            AUTO_INCREMENT PRIMARY KEY,
    bill_id         INT            NOT NULL,
    consumer_id     INT            NOT NULL,
    payment_date    DATE           NOT NULL,
    amount_paid     DECIMAL(10,2)  NOT NULL,
    payment_mode    ENUM('Cash', 'Cheque', 'Online', 'UPI') NOT NULL,
    receipt_number  VARCHAR(20)    NOT NULL UNIQUE,
    operator_id     INT            NOT NULL,
    FOREIGN KEY (bill_id)
        REFERENCES tbl_bills(bill_id)
        ON DELETE RESTRICT,
    FOREIGN KEY (consumer_id)
        REFERENCES tbl_consumers(consumer_id)
        ON DELETE RESTRICT,
    FOREIGN KEY (operator_id)
        REFERENCES tbl_users(user_id)
        ON DELETE RESTRICT,
    INDEX idx_bill_id        (bill_id),
    INDEX idx_consumer_id    (consumer_id),
    INDEX idx_payment_date   (payment_date),
    INDEX idx_receipt_number (receipt_number)
);
