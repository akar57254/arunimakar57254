-- ============================================================
-- sample_data.sql
-- Sample data for testing the Electricity Billing System
-- Run AFTER schema.sql
-- ============================================================

USE electricity_billing_db;

-- ============================================================
-- Default User Accounts
-- ============================================================
-- Admin Password: Admin@1234
INSERT INTO tbl_users (username, password_hash, full_name, role, email, created_date, status)
VALUES ('admin', SHA2('Admin@1234', 256), 'System Administrator', 'Administrator', 'admin@ebilling.com', CURDATE(), 'Active');

-- Operator Password: Operator@123
INSERT INTO tbl_users (username, password_hash, full_name, role, email, created_date, status)
VALUES ('operator1', SHA2('Operator@123', 256), 'Rajesh Kumar', 'Operator', 'rajesh@ebilling.com', CURDATE(), 'Active');

INSERT INTO tbl_users (username, password_hash, full_name, role, email, created_date, status)
VALUES ('operator2', SHA2('Operator@123', 256), 'Sunita Sharma', 'Operator', 'sunita@ebilling.com', CURDATE(), 'Active');

-- ============================================================
-- Tariff Configuration
-- ============================================================

-- Domestic Tariffs
INSERT INTO tbl_tariffs (connection_type, slab_from, slab_to, rate_per_unit, fixed_charge, fuel_surcharge, tax_percentage, effective_date)
VALUES
('Domestic',  0,    100,  3.00,  50.00,  5.00,  5.00, '2026-01-01'),
('Domestic',  101,  300,  5.00,  50.00,  5.00,  5.00, '2026-01-01'),
('Domestic',  301,  NULL, 7.00,  50.00,  5.00,  5.00, '2026-01-01');

-- Commercial Tariffs
INSERT INTO tbl_tariffs (connection_type, slab_from, slab_to, rate_per_unit, fixed_charge, fuel_surcharge, tax_percentage, effective_date)
VALUES
('Commercial', 0,    200,  6.00,  100.00, 8.00,  10.00, '2026-01-01'),
('Commercial', 201,  NULL, 9.00,  100.00, 8.00,  10.00, '2026-01-01');

-- Industrial Tariffs
INSERT INTO tbl_tariffs (connection_type, slab_from, slab_to, rate_per_unit, fixed_charge, fuel_surcharge, tax_percentage, effective_date)
VALUES
('Industrial', 0,    500,  8.00,  200.00, 10.00, 12.00, '2026-01-01'),
('Industrial', 501,  NULL, 11.00, 200.00, 10.00, 12.00, '2026-01-01');

-- ============================================================
-- Sample Consumers
-- ============================================================
INSERT INTO tbl_consumers (full_name, address, contact_number, email, meter_number, connection_type, sanctioned_load, connection_date, status)
VALUES
('Ramesh Sharma',      '12 MG Road, Sector 4, New Delhi - 110001',            '9876543210', 'ramesh@email.com',   'MTR-001', 'Domestic',   5.00,  '2020-06-15', 'Active'),
('Priya Verma',        '45 Park Street, Lajpat Nagar, New Delhi - 110024',     '9876543211', 'priya@email.com',    'MTR-002', 'Domestic',   3.00,  '2019-03-22', 'Active'),
('Suresh Patel',       '8 Gandhi Nagar, Dwarka, New Delhi - 110075',           '9876543213', 'suresh@email.com',   'MTR-003', 'Domestic',   4.00,  '2021-01-05', 'Active'),
('Anita Singh',        '23 Rose Garden, Rohini, New Delhi - 110085',           '9876543214', 'anita@email.com',    'MTR-004', 'Domestic',   5.00,  '2022-07-10', 'Active'),
('Vikram Mehta',       '67 Civil Lines, New Delhi - 110054',                   '9876543215', 'vikram@email.com',   'MTR-005', 'Domestic',   6.00,  '2018-09-30', 'Active'),
('Sunrise Enterprises','Plot 7, Industrial Area, Okhla, New Delhi - 110020',  '9876543216', 'sunrise@email.com',  'MTR-006', 'Commercial', 25.00, '2018-11-10', 'Active'),
('Delhi Book Store',   'Shop 12, Connaught Place, New Delhi - 110001',         '9876543217', 'books@email.com',    'MTR-007', 'Commercial', 10.00, '2020-04-15', 'Active'),
('Metro Textiles Ltd', 'B-12 Manufacturing Zone, Naraina, New Delhi - 110028','9876543218', 'metro@email.com',    'MTR-008', 'Industrial', 100.00,'2017-07-20', 'Active');
