# ============================================================
# main.py
# Electricity Billing System - Application Entry Point
# ============================================================

import tkinter as tk
from ui.login_ui     import LoginWindow
from ui.dashboard_ui import DashboardWindow


def start_login():
    """Launch the login window."""
    root = tk.Tk()
    app  = LoginWindow(root, on_login_success)
    root.mainloop()


def on_login_success(user):
    """Called after successful login — open dashboard."""
    # Find and close the login window
    for widget in tk._default_root.winfo_children():
        widget.destroy()
    tk._default_root.destroy()

    root = tk.Tk()
    DashboardWindow(root, user)
    root.mainloop()


if __name__ == "__main__":
    start_login()
